-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 14-09-2026 a las 19:43:58
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `agrosft_final`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `admin_audit_log`
--

CREATE TABLE `admin_audit_log` (
  `id_log` int(11) NOT NULL,
  `id_admin` int(11) DEFAULT NULL,
  `accion` varchar(100) NOT NULL,
  `objetivo` varchar(255) DEFAULT NULL,
  `detalles` text DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `fecha` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `auth_group`
--

CREATE TABLE `auth_group` (
  `id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `auth_group_permissions`
--

CREATE TABLE `auth_group_permissions` (
  `id` bigint(20) NOT NULL,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `auth_permission`
--

CREATE TABLE `auth_permission` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `auth_permission`
--

INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES
(1, 'Can add log entry', 1, 'add_logentry'),
(2, 'Can change log entry', 1, 'change_logentry'),
(3, 'Can delete log entry', 1, 'delete_logentry'),
(4, 'Can view log entry', 1, 'view_logentry'),
(5, 'Can add content type', 2, 'add_contenttype'),
(6, 'Can change content type', 2, 'change_contenttype'),
(7, 'Can delete content type', 2, 'delete_contenttype'),
(8, 'Can view content type', 2, 'view_contenttype'),
(9, 'Can add permission', 3, 'add_permission'),
(10, 'Can change permission', 3, 'change_permission'),
(11, 'Can delete permission', 3, 'delete_permission'),
(12, 'Can view permission', 3, 'view_permission'),
(13, 'Can add group', 4, 'add_group'),
(14, 'Can change group', 4, 'change_group'),
(15, 'Can delete group', 4, 'delete_group'),
(16, 'Can view group', 4, 'view_group'),
(17, 'Can add session', 5, 'add_session'),
(18, 'Can change session', 5, 'change_session'),
(19, 'Can delete session', 5, 'delete_session'),
(20, 'Can view session', 5, 'view_session'),
(21, 'Can add Usuario', 6, 'add_tblusuarios'),
(22, 'Can change Usuario', 6, 'change_tblusuarios'),
(23, 'Can delete Usuario', 6, 'delete_tblusuarios'),
(24, 'Can view Usuario', 6, 'view_tblusuarios'),
(25, 'Can add Dispositivo de Usuario', 7, 'add_userdevice'),
(26, 'Can change Dispositivo de Usuario', 7, 'change_userdevice'),
(27, 'Can delete Dispositivo de Usuario', 7, 'delete_userdevice'),
(28, 'Can view Dispositivo de Usuario', 7, 'view_userdevice'),
(29, 'Can add Dirección de Usuario', 8, 'add_useraddress'),
(30, 'Can change Dirección de Usuario', 8, 'change_useraddress'),
(31, 'Can delete Dirección de Usuario', 8, 'delete_useraddress'),
(32, 'Can view Dirección de Usuario', 8, 'view_useraddress'),
(33, 'Can add Perfil de Usuario', 9, 'add_userprofile'),
(34, 'Can change Perfil de Usuario', 9, 'change_userprofile'),
(35, 'Can delete Perfil de Usuario', 9, 'delete_userprofile'),
(36, 'Can view Perfil de Usuario', 9, 'view_userprofile'),
(37, 'Can add Log de Auditoría', 10, 'add_adminauditlog'),
(38, 'Can change Log de Auditoría', 10, 'change_adminauditlog'),
(39, 'Can delete Log de Auditoría', 10, 'delete_adminauditlog'),
(40, 'Can view Log de Auditoría', 10, 'view_adminauditlog'),
(41, 'Can add Estado', 11, 'add_estado'),
(42, 'Can change Estado', 11, 'change_estado'),
(43, 'Can delete Estado', 11, 'delete_estado'),
(44, 'Can view Estado', 11, 'view_estado'),
(45, 'Can add Tipo de Movimiento', 12, 'add_tipomovimiento'),
(46, 'Can change Tipo de Movimiento', 12, 'change_tipomovimiento'),
(47, 'Can delete Tipo de Movimiento', 12, 'delete_tipomovimiento'),
(48, 'Can view Tipo de Movimiento', 12, 'view_tipomovimiento'),
(49, 'Can add Categoría', 13, 'add_categoria'),
(50, 'Can change Categoría', 13, 'change_categoria'),
(51, 'Can delete Categoría', 13, 'delete_categoria'),
(52, 'Can view Categoría', 13, 'view_categoria'),
(53, 'Can add Producto', 14, 'add_producto'),
(54, 'Can change Producto', 14, 'change_producto'),
(55, 'Can delete Producto', 14, 'delete_producto'),
(56, 'Can view Producto', 14, 'view_producto'),
(57, 'Can add Producto de Usuario', 15, 'add_productousuario'),
(58, 'Can change Producto de Usuario', 15, 'change_productousuario'),
(59, 'Can delete Producto de Usuario', 15, 'delete_productousuario'),
(60, 'Can view Producto de Usuario', 15, 'view_productousuario'),
(61, 'Can add Calificación (Referencia)', 16, 'add_calificacion'),
(62, 'Can change Calificación (Referencia)', 16, 'change_calificacion'),
(63, 'Can delete Calificación (Referencia)', 16, 'delete_calificacion'),
(64, 'Can view Calificación (Referencia)', 16, 'view_calificacion'),
(65, 'Can add Cliente', 17, 'add_cliente'),
(66, 'Can change Cliente', 17, 'change_cliente'),
(67, 'Can delete Cliente', 17, 'delete_cliente'),
(68, 'Can view Cliente', 17, 'view_cliente'),
(69, 'Can add Tipo de Movimiento', 18, 'add_tipomovimiento'),
(70, 'Can change Tipo de Movimiento', 18, 'change_tipomovimiento'),
(71, 'Can delete Tipo de Movimiento', 18, 'delete_tipomovimiento'),
(72, 'Can view Tipo de Movimiento', 18, 'view_tipomovimiento'),
(73, 'Can add Movimiento', 19, 'add_movimiento'),
(74, 'Can change Movimiento', 19, 'change_movimiento'),
(75, 'Can delete Movimiento', 19, 'delete_movimiento'),
(76, 'Can view Movimiento', 19, 'view_movimiento'),
(77, 'Can add Detalle de Movimiento', 20, 'add_productousuariomovimiento'),
(78, 'Can change Detalle de Movimiento', 20, 'change_productousuariomovimiento'),
(79, 'Can delete Detalle de Movimiento', 20, 'delete_productousuariomovimiento'),
(80, 'Can view Detalle de Movimiento', 20, 'view_productousuariomovimiento'),
(81, 'Can add Factura', 21, 'add_factura'),
(82, 'Can change Factura', 21, 'change_factura'),
(83, 'Can delete Factura', 21, 'delete_factura'),
(84, 'Can view Factura', 21, 'view_factura'),
(85, 'Can add Item de Factura', 22, 'add_itemfactura'),
(86, 'Can change Item de Factura', 22, 'change_itemfactura'),
(87, 'Can delete Item de Factura', 22, 'delete_itemfactura'),
(88, 'Can view Item de Factura', 22, 'view_itemfactura'),
(89, 'Can add association', 23, 'add_association'),
(90, 'Can change association', 23, 'change_association'),
(91, 'Can delete association', 23, 'delete_association'),
(92, 'Can view association', 23, 'view_association'),
(93, 'Can add code', 24, 'add_code'),
(94, 'Can change code', 24, 'change_code'),
(95, 'Can delete code', 24, 'delete_code'),
(96, 'Can view code', 24, 'view_code'),
(97, 'Can add nonce', 25, 'add_nonce'),
(98, 'Can change nonce', 25, 'change_nonce'),
(99, 'Can delete nonce', 25, 'delete_nonce'),
(100, 'Can view nonce', 25, 'view_nonce'),
(101, 'Can add user social auth', 26, 'add_usersocialauth'),
(102, 'Can change user social auth', 26, 'change_usersocialauth'),
(103, 'Can delete user social auth', 26, 'delete_usersocialauth'),
(104, 'Can view user social auth', 26, 'view_usersocialauth'),
(105, 'Can add partial', 27, 'add_partial'),
(106, 'Can change partial', 27, 'change_partial'),
(107, 'Can delete partial', 27, 'delete_partial'),
(108, 'Can view partial', 27, 'view_partial'),
(109, 'Can add Imagen de Producto', 28, 'add_productoimagen'),
(110, 'Can change Imagen de Producto', 28, 'change_productoimagen'),
(111, 'Can delete Imagen de Producto', 28, 'delete_productoimagen'),
(112, 'Can view Imagen de Producto', 28, 'view_productoimagen');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `calificacion_bkp`
--

CREATE TABLE `calificacion_bkp` (
  `id_calificacion` int(11) NOT NULL DEFAULT 0,
  `calificacion` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `calificacion_bkp`
--

INSERT INTO `calificacion_bkp` (`id_calificacion`, `calificacion`) VALUES
(1, 5);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `clientes`
--

CREATE TABLE `clientes` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `nombre_completo` varchar(200) NOT NULL,
  `telefono` varchar(20) NOT NULL DEFAULT '',
  `direccion` text DEFAULT NULL,
  `fecha_registro` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `django_admin_log`
--

CREATE TABLE `django_admin_log` (
  `id` int(11) NOT NULL,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext DEFAULT NULL,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint(5) UNSIGNED NOT NULL CHECK (`action_flag` >= 0),
  `change_message` longtext NOT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `django_content_type`
--

CREATE TABLE `django_content_type` (
  `id` int(11) NOT NULL,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `django_content_type`
--

INSERT INTO `django_content_type` (`id`, `app_label`, `model`) VALUES
(1, 'admin', 'logentry'),
(4, 'auth', 'group'),
(3, 'auth', 'permission'),
(17, 'clientes', 'cliente'),
(2, 'contenttypes', 'contenttype'),
(21, 'facturacion', 'factura'),
(22, 'facturacion', 'itemfactura'),
(16, 'inventario', 'calificacion'),
(13, 'inventario', 'categoria'),
(11, 'inventario', 'estado'),
(14, 'inventario', 'producto'),
(28, 'inventario', 'productoimagen'),
(15, 'inventario', 'productousuario'),
(12, 'inventario', 'tipomovimiento'),
(5, 'sessions', 'session'),
(23, 'social_django', 'association'),
(24, 'social_django', 'code'),
(25, 'social_django', 'nonce'),
(27, 'social_django', 'partial'),
(26, 'social_django', 'usersocialauth'),
(10, 'usuarios', 'adminauditlog'),
(6, 'usuarios', 'tblusuarios'),
(8, 'usuarios', 'useraddress'),
(7, 'usuarios', 'userdevice'),
(9, 'usuarios', 'userprofile'),
(19, 'ventas', 'movimiento'),
(20, 'ventas', 'productousuariomovimiento'),
(18, 'ventas', 'tipomovimiento');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `django_migrations`
--

CREATE TABLE `django_migrations` (
  `id` bigint(20) NOT NULL,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `django_migrations`
--

INSERT INTO `django_migrations` (`id`, `app`, `name`, `applied`) VALUES
(1, 'facturacion', '0001_initial', '2026-06-30 19:21:51.127456'),
(2, 'facturacion', '0002_remove_factura_metodo_pago_remove_factura_pagada_en_and_more', '2026-06-30 19:21:53.468932'),
(3, 'contenttypes', '0001_initial', '2026-06-30 19:32:34.196389'),
(4, 'admin', '0001_initial', '2026-06-30 19:32:34.501391'),
(5, 'admin', '0002_logentry_remove_auto_add', '2026-06-30 19:32:34.512248'),
(6, 'admin', '0003_logentry_add_action_flag_choices', '2026-06-30 19:32:34.521813'),
(7, 'contenttypes', '0002_remove_content_type_name', '2026-06-30 19:32:34.632625'),
(8, 'auth', '0001_initial', '2026-06-30 19:32:35.086321'),
(9, 'auth', '0002_alter_permission_name_max_length', '2026-06-30 19:32:35.187310'),
(10, 'auth', '0003_alter_user_email_max_length', '2026-06-30 19:32:35.198130'),
(11, 'auth', '0004_alter_user_username_opts', '2026-06-30 19:32:35.216978'),
(12, 'auth', '0005_alter_user_last_login_null', '2026-06-30 19:32:35.253179'),
(13, 'auth', '0006_require_contenttypes_0002', '2026-06-30 19:32:35.256761'),
(14, 'auth', '0007_alter_validators_add_error_messages', '2026-06-30 19:32:35.266239'),
(15, 'auth', '0008_alter_user_username_max_length', '2026-06-30 19:32:35.276872'),
(16, 'auth', '0009_alter_user_last_name_max_length', '2026-06-30 19:32:35.287736'),
(17, 'auth', '0010_alter_group_name_max_length', '2026-06-30 19:32:35.323452'),
(18, 'auth', '0011_update_proxy_permissions', '2026-06-30 19:32:35.371013'),
(19, 'auth', '0012_alter_user_first_name_max_length', '2026-06-30 19:32:35.383620'),
(20, 'sessions', '0001_initial', '2026-06-30 19:32:35.469972'),
(21, 'default', '0001_initial', '2026-06-30 19:32:35.809535'),
(22, 'social_auth', '0001_initial', '2026-06-30 19:32:35.812344'),
(23, 'default', '0002_add_related_name', '2026-06-30 19:32:35.831208'),
(24, 'social_auth', '0002_add_related_name', '2026-06-30 19:32:35.834087'),
(25, 'default', '0003_alter_email_max_length', '2026-06-30 19:32:35.848651'),
(26, 'social_auth', '0003_alter_email_max_length', '2026-06-30 19:32:35.851269'),
(27, 'default', '0004_auto_20160423_0400', '2026-06-30 19:32:35.862918'),
(28, 'social_auth', '0004_auto_20160423_0400', '2026-06-30 19:32:35.865542'),
(29, 'social_auth', '0005_auto_20160727_2333', '2026-06-30 19:32:35.887867'),
(30, 'social_django', '0006_partial', '2026-06-30 19:32:35.944889'),
(31, 'social_django', '0007_code_timestamp', '2026-06-30 19:32:35.988678'),
(32, 'social_django', '0008_partial_timestamp', '2026-06-30 19:32:36.035292'),
(33, 'social_django', '0009_auto_20191118_0520', '2026-06-30 19:32:36.104254'),
(34, 'social_django', '0010_uid_db_index', '2026-06-30 19:32:36.133441'),
(35, 'social_django', '0011_alter_id_fields', '2026-06-30 19:32:36.699932'),
(36, 'social_django', '0012_usersocialauth_extra_data_new', '2026-06-30 19:32:36.814055'),
(37, 'social_django', '0013_migrate_extra_data', '2026-06-30 19:32:36.857300'),
(38, 'social_django', '0014_remove_usersocialauth_extra_data', '2026-06-30 19:32:36.891527'),
(39, 'social_django', '0015_rename_extra_data_new_usersocialauth_extra_data', '2026-06-30 19:32:37.034500'),
(40, 'social_django', '0002_add_related_name', '2026-06-30 19:32:37.042326'),
(41, 'social_django', '0004_auto_20160423_0400', '2026-06-30 19:32:37.045379'),
(42, 'social_django', '0005_auto_20160727_2333', '2026-06-30 19:32:37.048066'),
(43, 'social_django', '0001_initial', '2026-06-30 19:32:37.050890'),
(44, 'social_django', '0003_alter_email_max_length', '2026-06-30 19:32:37.053860');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `django_session`
--

CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estado`
--

CREATE TABLE `estado` (
  `id_estado` int(11) NOT NULL,
  `estado` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `estado`
--

INSERT INTO `estado` (`id_estado`, `estado`) VALUES
(1, 'Aprobado'),
(2, 'Pendiente'),
(3, 'Rechazado');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `factura`
--

CREATE TABLE `factura` (
  `id_factura` int(11) NOT NULL,
  `numero_factura` varchar(50) DEFAULT NULL,
  `total` decimal(12,2) NOT NULL,
  `estado` varchar(20) NOT NULL,
  `payer_email` varchar(255) NOT NULL,
  `creada_en` datetime(6) NOT NULL,
  `pdf_generado` tinyint(1) NOT NULL,
  `id_movimiento` int(11) DEFAULT NULL,
  `id_usuario` int(11) NOT NULL,
  `metodo_pago_nombre` varchar(60) NOT NULL,
  `id_vendedor` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `factura`
--

INSERT INTO `factura` (`id_factura`, `numero_factura`, `total`, `estado`, `payer_email`, `creada_en`, `pdf_generado`, `id_movimiento`, `id_usuario`, `metodo_pago_nombre`, `id_vendedor`) VALUES
(1, NULL, 40000.00, 'emitida', 'samupe2903@gmail.com', '2026-09-01 22:04:52.433712', 0, 17, 7, '', NULL),
(2, NULL, 259800000.00, 'emitida', 'samupe2903@gmail.com', '2026-09-04 20:12:20.761679', 0, 21, 7, '', NULL),
(3, NULL, 259800000.00, 'emitida', 'samupe2903@gmail.com', '2026-09-09 09:56:51.933801', 0, 21, 7, '', 7),
(4, NULL, 600000.00, 'emitida', 'samupe2903@gmail.com', '2026-09-09 11:07:14.553662', 0, 22, 7, '', 7),
(5, NULL, 9000.00, 'emitida', 'samupe2903@gmail.com', '2026-09-09 11:07:30.960734', 1, 9, 7, '', 7),
(6, NULL, -500000.00, 'emitida', 'danibaron456@gmail.com', '2026-09-14 01:41:09.651095', 0, 43, 13, '', 13);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `item_factura`
--

CREATE TABLE `item_factura` (
  `id_item` int(11) NOT NULL,
  `descripcion` varchar(255) NOT NULL,
  `cantidad` decimal(10,2) NOT NULL,
  `precio_unitario` decimal(12,2) NOT NULL,
  `subtotal` decimal(12,2) NOT NULL,
  `id_factura` int(11) NOT NULL,
  `id_producto` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `item_factura`
--

INSERT INTO `item_factura` (`id_item`, `descripcion`, `cantidad`, `precio_unitario`, `subtotal`, `id_factura`, `id_producto`) VALUES
(1, 'holaaaa - sebastian perez mena', 1.00, 40000.00, 40000.00, 1, 23),
(2, 'HOLA - samuel perez mena', 866.00, 300000.00, 259800000.00, 2, 27),
(3, 'HOLA', 866.00, 300000.00, 259800000.00, 3, 27),
(4, 'HOLA', 2.00, 300000.00, 600000.00, 4, 27),
(5, 'salchipapa', 3.00, 3000.00, 9000.00, 5, 1),
(6, 'tomate cafe', 10.00, -50000.00, -500000.00, 6, 45);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `movimiento`
--

CREATE TABLE `movimiento` (
  `id_movimiento` int(11) NOT NULL,
  `tipo_movimiento_id_tipo_movimiento` int(11) NOT NULL,
  `tblusuarios_id_users` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `movimiento`
--

INSERT INTO `movimiento` (`id_movimiento`, `tipo_movimiento_id_tipo_movimiento`, `tblusuarios_id_users`) VALUES
(1, 5, 8),
(2, 5, 8),
(3, 5, 8),
(4, 5, 7),
(5, 5, 7),
(6, 3, 8),
(7, 3, 8),
(8, 3, 8),
(9, 3, 7),
(10, 4, 8),
(11, 3, 8),
(12, 3, 8),
(13, 2, 8),
(14, 3, 7),
(15, 3, 8),
(17, 1, 7),
(18, 3, 7),
(19, 2, 7),
(20, 2, 7),
(21, 3, 7),
(22, 2, 7),
(23, 1, 7),
(24, 1, 7),
(25, 1, 7),
(26, 1, 7),
(27, 1, 7),
(28, 1, 7),
(29, 1, 7),
(30, 1, 13),
(31, 1, 13),
(32, 1, 13),
(33, 1, 13),
(34, 1, 13),
(35, 6, 13),
(36, 1, 14),
(37, 2, 13),
(38, 1, 13),
(39, 1, 13),
(40, 1, 15),
(41, 1, 13),
(42, 1, 13),
(43, 1, 13);

--
-- Disparadores `movimiento`
--
DELIMITER $$
CREATE TRIGGER `trg_descontar_stock_vendida` AFTER UPDATE ON `movimiento` FOR EACH ROW BEGIN
    DECLARE v_tipo_nuevo VARCHAR(45);
    DECLARE v_tipo_viejo VARCHAR(45);

    
    SELECT tipo_movimiento INTO v_tipo_nuevo
    FROM tipo_movimiento WHERE id_tipo_movimiento = NEW.tipo_movimiento_id_tipo_movimiento;

    SELECT tipo_movimiento INTO v_tipo_viejo
    FROM tipo_movimiento WHERE id_tipo_movimiento = OLD.tipo_movimiento_id_tipo_movimiento;

    
    IF v_tipo_nuevo = 'vendida' AND v_tipo_viejo != 'vendida' THEN
        UPDATE tblproductos_has_tblusuarios pu
        INNER JOIN tblproductos_has_tblusuarios_has_movimiento pum
            ON pu.id_pd_us = pum.tblproductos_has_tblusuarios_id_pd_us
        SET pu.cantidad = pu.cantidad - ABS(pum.cantidad)
        WHERE pum.movimiento_id_movimiento = NEW.id_movimiento
          AND pum.cantidad != 0;
    END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `resena_bkp`
--

CREATE TABLE `resena_bkp` (
  `id_resena` int(11) NOT NULL DEFAULT 0,
  `id_movimiento_usuario` int(11) NOT NULL,
  `tblproductos_has_tblusuarios_id_pd_us` int(11) NOT NULL,
  `tblusuarios_id_users` int(11) NOT NULL,
  `calificacion` tinyint(1) NOT NULL,
  `comentario` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `resena_bkp`
--

INSERT INTO `resena_bkp` (`id_resena`, `id_movimiento_usuario`, `tblproductos_has_tblusuarios_id_pd_us`, `tblusuarios_id_users`, `calificacion`, `comentario`, `fecha_creacion`) VALUES
(1, 28, 14, 12, 5, NULL, '2026-09-09 05:24:49'),
(2, 24, 14, 12, 5, NULL, '2026-09-09 05:28:08'),
(3, 34, 10, 12, 5, 'me encanta en pjpi', '2026-09-09 05:35:31');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `social_auth_association`
--

CREATE TABLE `social_auth_association` (
  `id` bigint(20) NOT NULL,
  `server_url` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `secret` varchar(255) NOT NULL,
  `issued` int(11) NOT NULL,
  `lifetime` int(11) NOT NULL,
  `assoc_type` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `social_auth_code`
--

CREATE TABLE `social_auth_code` (
  `id` bigint(20) NOT NULL,
  `email` varchar(254) NOT NULL,
  `code` varchar(32) NOT NULL,
  `verified` tinyint(1) NOT NULL,
  `timestamp` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `social_auth_nonce`
--

CREATE TABLE `social_auth_nonce` (
  `id` bigint(20) NOT NULL,
  `server_url` varchar(255) NOT NULL,
  `timestamp` int(11) NOT NULL,
  `salt` varchar(65) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `social_auth_partial`
--

CREATE TABLE `social_auth_partial` (
  `id` bigint(20) NOT NULL,
  `token` varchar(32) NOT NULL,
  `next_step` smallint(5) UNSIGNED NOT NULL CHECK (`next_step` >= 0),
  `backend` varchar(32) NOT NULL,
  `timestamp` datetime(6) NOT NULL,
  `data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`data`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `social_auth_usersocialauth`
--

CREATE TABLE `social_auth_usersocialauth` (
  `id` bigint(20) NOT NULL,
  `provider` varchar(32) NOT NULL,
  `uid` varchar(255) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created` datetime(6) NOT NULL,
  `modified` datetime(6) NOT NULL,
  `extra_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`extra_data`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `social_auth_usersocialauth`
--

INSERT INTO `social_auth_usersocialauth` (`id`, `provider`, `uid`, `user_id`, `created`, `modified`, `extra_data`) VALUES
(1, 'google-oauth2', 'danibaron456@gmail.com', 13, '2026-09-09 11:27:37.740955', '2026-09-14 01:20:18.447042', '{\"auth_time\": 1789348818, \"expires_in\": 3598, \"token_type\": \"Bearer\", \"access_token\": \"ya29.a0AdMD6EjsIl0AXP-tdK_BTNIKxl7yoFyq7xcaOBF2Ey4R9JKqhHDI6J_dpS6lkRQ0i6NHZC1TXkSS_dSnA81gRgbry4hvoBmNMcwu7RCxXF3CQ3rPebaKSjDJc_JSJ0HwtNg0Wwn7luCh7PO5JHZDzO4LrZpcH1SsiX13X3ivSL0AykXjpd_aXreq8CGpKCCgvK0VUhr4l6PS-2WaOuSn5l2VW9QURsXgoFSjh1IAGT5mS7ZnG3rFXkvLtbguL_XXznl3MZzyPYMTKBEJTmSE2S3zovMQnQaCgYKARgSARISFQHGX2Miz_tjXCLW7cfeLFhtfL_JFg0293\"}'),
(2, 'google-oauth2', 'danibaron446@gmail.com', 14, '2026-09-09 12:47:13.437393', '2026-09-09 12:51:54.445435', '{\"auth_time\": 1788958314, \"expires_in\": 3597, \"token_type\": \"Bearer\", \"access_token\": \"ya29.a0AdMD6EhlyW5hk-6kvsUBSQ5l_4Yg14GSq8hN6Rz2IpwEv5ubq-1Nub46MscbgDu9prHUwfFUJkLzIejj6qhOfmb4zkUZSXd26_3b0HlM-Y32H9RI0sL_p2scWYMKyn4Qx0twHbu_O_f9qNOvmylqQwojogWxtb2aAFWvWSEAzGhIbGUIUgKXV5WPsQ4gV2iVg64XnDnxfJKJhhZuCGzcIwM-b-zYZbfXkcNFL_SRscPKNW89ybR-rwTuhQuKivYEl4eYy7zgBXz8rA_Z2RT-tPJV6VpI3CAaCgYKAdcSARASFQHGX2Mioel1Rv_1ObpvcJkseqMmjw0294\"}'),
(3, 'google-oauth2', 'sofiaalvarezruiz279@gmail.com', 15, '2026-09-09 12:52:30.075363', '2026-09-09 12:53:59.621553', '{\"auth_time\": 1788958439, \"expires_in\": 3598, \"token_type\": \"Bearer\", \"access_token\": \"ya29.a0AdMD6EgSUOKm6RUGnmVLhu1gMBH-M-_z5pTzQLLUBZ42hO2gJeglheqPA0Hm33XHGcofPvUeZR6ue9IpExOF1z2NaYsn7yex5NwQyUF7y9dYT9LS9rTZVIFV6QU8cHIpq3NH7jEahtD3AWECqVDM2zIVfPAVcRgmqm8fSNGYFFPNmZPr3_hbXKKpt1ClfUU3ztyZ4deeGttBY4lLAYoqBFCbg69BKxytQNYLSJ08aUdXgo7WhtSZW9rmQXT0MYRzYGHTWZCdeE9bHjhB-bwry-FQpuQaCgYKAT0SARYSFQHGX2MiqgpMN8XQ2aJUNwnSZvw2ug0290\"}');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tblcategoria`
--

CREATE TABLE `tblcategoria` (
  `idt_categoria` int(11) NOT NULL,
  `categoria` varchar(45) NOT NULL,
  `descripcion` text DEFAULT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime(6) DEFAULT NULL,
  `updated_at` datetime(6) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `tblcategoria`
--

INSERT INTO `tblcategoria` (`idt_categoria`, `categoria`, `descripcion`, `activo`, `created_at`, `updated_at`) VALUES
(1, 'Frutas', 'Frutas frescas de temporada', 1, '2026-05-04 16:54:24.000000', '2026-05-04 16:54:24.000000'),
(2, 'Verduras', 'Verduras y vegetales frescos', 1, '2026-05-04 16:54:24.000000', '2026-05-04 16:54:24.000000'),
(3, 'Tubérculos', 'Papas, yucas y otros tubérculos', 1, '2026-05-04 16:54:24.000000', '2026-05-04 16:54:24.000000'),
(4, 'Granos y Cereales', 'Frijoles, lentejas, maíz, arroz, etc.', 1, '2026-05-04 16:54:24.000000', '2026-05-04 16:54:24.000000'),
(5, 'Insumos Agrícolas', 'Fertilizantes, semillas y herramientas', 1, '2026-05-04 16:54:24.000000', '2026-05-04 16:54:24.000000');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tblproducto`
--

CREATE TABLE `tblproducto` (
  `id_productos` int(11) NOT NULL,
  `nombre` varchar(45) NOT NULL,
  `cantidad` int(11) NOT NULL,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  `tblcategoria_idt_categoria` int(11) NOT NULL,
  `tblunidad_medida_id_unidad` int(11) DEFAULT 1,
  `descripcion` text DEFAULT NULL,
  `imagen` varchar(255) DEFAULT NULL COMMENT 'Ruta o URL de la imagen del producto',
  `stock_minimo` int(11) NOT NULL DEFAULT 5,
  `eliminado` tinyint(1) NOT NULL DEFAULT 0,
  `fecha_eliminacion` datetime(6) DEFAULT NULL,
  `eliminado_por_id` int(11) DEFAULT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  `unidad_medida_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `tblproducto`
--

INSERT INTO `tblproducto` (`id_productos`, `nombre`, `cantidad`, `fecha_creacion`, `tblcategoria_idt_categoria`, `tblunidad_medida_id_unidad`, `descripcion`, `imagen`, `stock_minimo`, `eliminado`, `fecha_eliminacion`, `eliminado_por_id`, `updated_at`, `unidad_medida_id`) VALUES
(1, 'salchipapa', 15, '2026-05-05 02:56:06', 4, 1, 'hola tyujikl', NULL, 3, 1, '2026-05-29 02:49:42.112579', 7, '2026-05-04 21:56:06.714761', 1),
(2, 'Manzanas Rojas', 150, '2026-05-04 22:00:30', 1, 1, 'Manzanas frescas y dulces, recién cosechadas.', NULL, 20, 0, NULL, NULL, '2026-05-04 17:00:30.000000', 1),
(3, 'Plátano Verde', 300, '2026-05-04 22:00:30', 1, 1, 'Plátano verde ideal para patacones.', NULL, 50, 0, NULL, NULL, '2026-05-04 17:00:30.000000', 1),
(4, 'Zanahorias', 200, '2026-05-04 22:00:30', 2, 1, 'Zanahorias orgánicas ricas en vitamina A.', NULL, 30, 1, '2026-08-24 10:12:46.000000', NULL, '2026-05-04 17:00:30.000000', 1),
(5, 'Tomate Chonto', 180, '2026-05-04 22:00:30', 2, 1, 'Tomate rojo perfecto para ensaladas y guisos.', NULL, 40, 1, '2026-08-24 10:12:42.000000', NULL, '2026-05-04 17:00:30.000000', 1),
(6, 'Papa Pastusa', 500, '2026-05-04 22:00:30', 3, 1, 'Papa de excelente calidad para purés y sopas.', NULL, 100, 0, NULL, NULL, '2026-05-04 17:00:30.000000', 1),
(7, 'Yuca Fresca', 250, '2026-05-04 22:00:30', 3, 1, 'Yuca suave y harinosa, fácil de cocinar.', NULL, 40, 0, NULL, NULL, '2026-05-04 17:00:30.000000', 1),
(8, 'Frijol Cargamanto', 100, '2026-05-04 22:00:30', 4, 1, 'Frijol grande y nutritivo, cultivo limpio.', NULL, 20, 0, NULL, NULL, '2026-05-04 17:00:30.000000', 1),
(9, 'Arroz Blanco', 600, '2026-05-04 22:00:30', 4, 1, 'Arroz de grano entero, excelente cocción.', NULL, 100, 1, '2026-08-24 10:12:36.000000', NULL, '2026-05-04 17:00:30.000000', 1),
(10, 'Abono Orgánico', 50, '2026-05-04 22:00:30', 5, 1, 'Abono 100% natural rico en nutrientes para sus cultivos.', NULL, 10, 1, '2026-08-24 10:12:32.000000', NULL, '2026-05-04 17:00:30.000000', 1),
(11, 'Semillas de Tomate', 200, '2026-05-04 22:00:30', 5, 1, 'Paquete de semillas certificadas de alto rendimiento.', NULL, 50, 0, NULL, NULL, '2026-05-04 17:00:30.000000', 1),
(12, 'Cebolla Cabezona', 350, '2026-05-04 22:00:30', 2, 1, 'Cebolla blanca de buen tamaño y sabor.', NULL, 50, 0, NULL, NULL, '2026-05-04 17:00:30.000000', 1),
(13, 'Naranja Valencia', 400, '2026-05-04 22:00:30', 1, 1, 'Naranjas jugosas ideales para exprimir.', NULL, 80, 0, NULL, NULL, '2026-05-04 17:00:30.000000', 1),
(14, 'Lentejas', 150, '2026-05-04 22:00:30', 4, 1, 'Lenteja de rápida cocción, alta proteína.', NULL, 30, 0, NULL, NULL, '2026-05-04 17:00:30.000000', 1),
(15, 'Papa Criolla', 300, '2026-05-04 22:00:30', 3, 1, 'Papa criolla amarilla pequeña, muy sabrosa.', NULL, 60, 0, NULL, NULL, '2026-05-04 17:00:30.000000', 1),
(16, 'Fertilizante NPK', 40, '2026-05-04 22:00:30', 5, 1, 'Fertilizante equilibrado para fase de crecimiento.', NULL, 5, 0, NULL, NULL, '2026-05-04 17:00:30.000000', 1),
(17, 'Papa', 1, '2026-05-05 03:43:29', 2, 1, 'hola', NULL, 5, 0, NULL, NULL, '2026-05-04 22:43:29.280005', 1),
(18, 'coco', 50, '2026-05-05 05:18:04', 1, 1, 'coco delicioso', NULL, 5, 0, NULL, NULL, '2026-05-05 00:18:04.362487', 1),
(19, 'ensalada', 0, '2026-05-29 09:34:41', 4, 1, 'hrloooo', NULL, 5, 0, NULL, NULL, NULL, 1),
(20, 'mango', 0, '2026-05-29 09:35:05', 1, 1, 'rico', 'productos/carpeta.png', 5, 0, NULL, NULL, NULL, 1),
(21, 'semillas de alfajore', 0, '2026-05-29 09:35:32', 5, 1, 'melas j', 'productos/Gemini_Generated_Image_6pevu46pevu46pev.png', 5, 0, NULL, NULL, NULL, 1),
(22, 'ensalada fria', 0, '2026-06-18 01:04:21', 2, 1, 'melisa es una sapa', '', 5, 1, '2026-08-24 10:12:20.000000', NULL, NULL, 1),
(23, 'holaaaa', 0, '2026-06-30 12:40:46', 2, 1, 'fghjkl', NULL, 5, 0, NULL, NULL, NULL, 1),
(25, 'PIÑA COLADA', 13, '2026-08-24 15:30:22', 2, 1, 'PIÑA COLADA', NULL, 5, 0, NULL, NULL, NULL, 1),
(26, 'salchipapa', 56, '2026-08-24 22:45:27', 2, 1, 'queso', NULL, 5, 0, NULL, NULL, NULL, 1),
(27, 'HOLA', 0, '2026-09-02 06:14:37', 1, 1, 'youiioiuyhgfdfgh', '', 5, 0, NULL, NULL, NULL, 1),
(28, 'filipooo', 0, '2026-09-02 06:59:10', 1, 1, 'hola', 'productos/ChatGPT_Image_5_ago_2026_08_49_18_p.m_L8LLvgI.png', 6, 0, NULL, NULL, NULL, 1),
(29, 'sachipapapaaas', 0, '2026-09-02 07:07:49', 1, 1, 'pupiotoo', 'productos/ChatGPT_Image_5_ago_2026_08_49_18_p.m_KNM1avp.png', 9, 0, NULL, NULL, NULL, 1),
(30, 'mango locooo', 56, '2026-09-07 14:23:15', 1, 1, 'melos', 'productos/agua.png', 45, 0, NULL, NULL, NULL, 1),
(31, 'mangoñpcpp', 67, '2026-09-07 15:58:26', 1, 1, 'dfghjkl', 'productos/carpeta_Gc0JHyn.png', 6, 0, NULL, NULL, NULL, 1),
(32, 'semillas de alfajore', 23, '2026-09-07 16:23:48', 4, 1, 'fghjkl', 'productos/ChatGPT_Image_5_ago_2026_08_49_18_p.m_ZjCKGda.png', 3, 0, NULL, NULL, NULL, 1),
(33, 'Yuca Fresca', 20, '2026-09-09 17:07:48', 3, 3, '', 'productos/yuca.jpg', 10, 0, NULL, NULL, NULL, NULL),
(34, 'coco', 10, '2026-09-09 17:09:03', 1, 1, 'a buen precio, negociable', 'productos/coco.webp', 5, 0, NULL, NULL, NULL, NULL),
(35, 'mango', 40, '2026-09-09 17:10:16', 1, 2, 'mango puerco', 'productos/mango.jpg', 15, 0, NULL, NULL, NULL, NULL),
(36, 'Manzanas Rojas', 40, '2026-09-09 17:12:30', 1, 2, '', 'productos/OIP.webp', 10, 0, NULL, NULL, NULL, NULL),
(37, 'Plátano Verde', 50, '2026-09-09 17:15:13', 2, 2, '', 'productos/platano.webp', 20, 0, NULL, NULL, NULL, NULL),
(38, 'Papa Criolla', 51, '2026-09-09 17:16:25', 3, 3, '', 'productos/papa_criolla.webp', 15, 0, NULL, NULL, NULL, NULL),
(39, 'Cebolla Cabezona', 39, '2026-09-09 17:18:12', 2, 3, '', 'productos/cebolla.webp', 9, 0, NULL, NULL, NULL, NULL),
(40, 'Frijol Cargamanto', 50, '2026-09-09 17:20:42', 4, 3, '', 'productos/frijo.webp', 10, 0, NULL, NULL, NULL, NULL),
(41, 'tomate rojo', 10, '2026-09-09 17:43:03', 2, 4, 'tomate fresco', 'productos/papa_criolla_Or0rdYO.webp', 2, 0, NULL, NULL, NULL, NULL),
(42, 'Semillas de Tomate', 30, '2026-09-09 17:47:56', 5, 2, 'semilllas a buen precio', 'productos/mango_brTNvKJ.jpg', 10, 0, NULL, NULL, NULL, NULL),
(43, 'mango locooo', 60, '2026-09-09 17:53:06', 1, 3, 'mango locooo', 'productos/mango_UaHxEtk.jpg', 5, 0, NULL, NULL, NULL, NULL),
(44, 'tomate verde', 50, '2026-09-13 07:17:52', 2, 3, 'dad', 'productos/frijo_VSrpKYk.webp', 20, 0, NULL, NULL, NULL, NULL),
(45, 'tomate cafe', 10, '2026-09-14 06:26:46', 2, 3, '', 'productos/1_y993Pnc.jpg', 4, 0, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tblproductos_has_tblusuarios`
--

CREATE TABLE `tblproductos_has_tblusuarios` (
  `tblproductos_id_productos` int(11) NOT NULL,
  `tblusuarios_id_users` int(11) NOT NULL,
  `id_pd_us` int(11) NOT NULL,
  `cantidad` decimal(10,2) NOT NULL DEFAULT 0.00 COMMENT 'Stock disponible para esta publicación',
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  `precio` decimal(10,2) NOT NULL DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `tblproductos_has_tblusuarios`
--

INSERT INTO `tblproductos_has_tblusuarios` (`tblproductos_id_productos`, `tblusuarios_id_users`, `id_pd_us`, `cantidad`, `fecha_creacion`, `precio`) VALUES
(23, 8, 13, 44.00, '2026-06-30 12:40:46', 40000.00),
(33, 7, 20, 20.00, '2026-09-09 17:07:48', 5000.00),
(34, 7, 21, 10.00, '2026-09-09 17:09:03', 7000.00),
(35, 7, 22, 40.00, '2026-09-09 17:10:16', 4000.00),
(36, 7, 23, 40.00, '2026-09-09 17:12:30', 3500.00),
(37, 13, 24, 50.00, '2026-09-09 17:15:13', 2000.00),
(38, 13, 25, 51.00, '2026-09-09 17:16:25', 3000.00),
(39, 13, 26, 39.00, '2026-09-09 17:18:12', 3500.00),
(40, 13, 27, 50.00, '2026-09-09 17:20:42', 10000.00),
(41, 13, 28, 20.00, '2026-09-09 17:43:03', 5000.00),
(42, 14, 29, 30.00, '2026-09-09 17:47:56', 5000.00),
(43, 15, 30, 60.00, '2026-09-09 17:53:06', 40000.00),
(44, 13, 31, 50.00, '2026-09-13 07:17:52', 2500.00),
(45, 13, 32, 10.00, '2026-09-14 06:26:46', 49999.96);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tblproductos_has_tblusuarios_has_movimiento`
--

CREATE TABLE `tblproductos_has_tblusuarios_has_movimiento` (
  `tblproductos_has_tblusuarios_id_pd_us` int(11) NOT NULL,
  `movimiento_id_movimiento` int(11) NOT NULL,
  `id_movimiento_usuario` int(11) NOT NULL,
  `cantidad` decimal(10,2) NOT NULL DEFAULT 0.00 COMMENT 'Cantidad movida (positiva=entrada, negativa=salida)',
  `fecha_movimiento` timestamp NOT NULL DEFAULT current_timestamp() COMMENT 'Fecha y hora del movimiento'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `tblproductos_has_tblusuarios_has_movimiento`
--

INSERT INTO `tblproductos_has_tblusuarios_has_movimiento` (`tblproductos_has_tblusuarios_id_pd_us`, `movimiento_id_movimiento`, `id_movimiento_usuario`, `cantidad`, `fecha_movimiento`) VALUES
(13, 13, 21, 45.00, '2026-06-30 12:40:46'),
(13, 14, 22, -1.00, '2026-06-30 12:41:57'),
(13, 17, 24, -1.00, '2026-09-02 03:04:52'),
(20, 26, 33, 20.00, '2026-09-09 17:07:48'),
(21, 27, 34, 10.00, '2026-09-09 17:09:03'),
(22, 28, 35, 40.00, '2026-09-09 17:10:16'),
(23, 29, 36, 40.00, '2026-09-09 17:12:30'),
(24, 30, 37, 50.00, '2026-09-09 17:15:13'),
(25, 31, 38, 51.00, '2026-09-09 17:16:25'),
(26, 32, 39, 39.00, '2026-09-09 17:18:12'),
(27, 33, 40, 50.00, '2026-09-09 17:20:42'),
(28, 34, 41, 10.00, '2026-09-09 17:43:03'),
(28, 35, 42, 10.00, '2026-09-09 17:44:20'),
(29, 36, 43, 30.00, '2026-09-09 17:47:56'),
(29, 37, 44, -1.00, '2026-09-09 17:48:27'),
(20, 37, 45, -1.00, '2026-09-09 17:48:27'),
(29, 38, 46, -1.00, '2026-09-09 17:50:11'),
(23, 38, 47, -1.00, '2026-09-09 17:50:11'),
(29, 39, 48, -1.00, '2026-09-09 17:51:06'),
(23, 39, 49, -1.00, '2026-09-09 17:51:06'),
(30, 40, 50, 60.00, '2026-09-09 17:53:06'),
(30, 41, 51, -1.00, '2026-09-09 17:53:32'),
(23, 41, 52, -1.00, '2026-09-09 17:53:32'),
(31, 42, 53, 50.00, '2026-09-13 07:17:52'),
(32, 43, 54, 10.00, '2026-09-14 06:26:46');

--
-- Disparadores `tblproductos_has_tblusuarios_has_movimiento`
--
DELIMITER $$
CREATE TRIGGER `trg_actualizar_stock_oferta` AFTER INSERT ON `tblproductos_has_tblusuarios_has_movimiento` FOR EACH ROW BEGIN
    DECLARE v_tipo VARCHAR(45);
    DECLARE v_stock_actual DECIMAL(10,2);

    -- Obtener el tipo de movimiento
    SELECT tm.tipo_movimiento INTO v_tipo
    FROM movimiento m
    JOIN tipo_movimiento tm ON m.tipo_movimiento_id_tipo_movimiento = tm.id_tipo_movimiento
    WHERE m.id_movimiento = NEW.movimiento_id_movimiento;

    -- Si NO es compra, validar y actualizar stock
    IF v_tipo != 'compra' THEN

        -- Validar que no haya stock negativo en salidas
        IF NEW.cantidad < 0 THEN
            SELECT cantidad INTO v_stock_actual
            FROM tblproductos_has_tblusuarios
            WHERE id_pd_us = NEW.tblproductos_has_tblusuarios_id_pd_us;

            IF v_stock_actual + NEW.cantidad < 0 THEN
                SIGNAL SQLSTATE '45000'
                SET MESSAGE_TEXT = 'Stock insuficiente: la cantidad solicitada excede el stock disponible';
            END IF;
        END IF;

        -- Actualizar stock del producto
        UPDATE tblproductos_has_tblusuarios
        SET cantidad = cantidad + NEW.cantidad
        WHERE id_pd_us = NEW.tblproductos_has_tblusuarios_id_pd_us;
    END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tblproducto_imagenes`
--

CREATE TABLE `tblproducto_imagenes` (
  `id` int(11) NOT NULL,
  `id_producto` int(11) NOT NULL,
  `imagen` varchar(255) NOT NULL,
  `orden` int(11) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `tblproducto_imagenes`
--

INSERT INTO `tblproducto_imagenes` (`id`, `id_producto`, `imagen`, `orden`, `created_at`) VALUES
(1, 30, 'productos/atomo_1.png', 1, '2026-09-07 09:23:15'),
(2, 30, 'productos/atomo.png', 2, '2026-09-07 09:23:15');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tblunidad_medida`
--

CREATE TABLE `tblunidad_medida` (
  `id_unidad` int(11) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `abreviatura` varchar(10) NOT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime(6) DEFAULT NULL,
  `updated_at` datetime(6) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `tblunidad_medida`
--

INSERT INTO `tblunidad_medida` (`id_unidad`, `nombre`, `abreviatura`, `activo`, `created_at`, `updated_at`) VALUES
(1, 'Unidades', 'u', 1, '2026-09-09 04:51:08.000000', NULL),
(2, 'Kilogramos', 'kg', 1, '2026-09-09 04:51:08.000000', NULL),
(3, 'Libras', 'lb', 1, '2026-09-09 04:51:08.000000', NULL),
(4, 'Litros', 'L', 1, '2026-09-09 04:51:08.000000', NULL),
(5, 'Gramos', 'g', 1, '2026-09-09 04:51:08.000000', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tblusuarios`
--

CREATE TABLE `tblusuarios` (
  `id_users` int(11) NOT NULL,
  `nombres` varchar(45) NOT NULL,
  `apellidos` varchar(45) NOT NULL,
  `Telefono` varchar(45) NOT NULL,
  `correo` varchar(45) NOT NULL,
  `contraseña` varchar(255) DEFAULT NULL,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL DEFAULT 0,
  `is_staff` tinyint(1) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `tblusuarios`
--

INSERT INTO `tblusuarios` (`id_users`, `nombres`, `apellidos`, `Telefono`, `correo`, `contraseña`, `fecha_creacion`, `last_login`, `is_superuser`, `is_staff`, `is_active`) VALUES
(7, 'samuel', 'perez mena', '3154840318', 'samupe2903@gmail.com', 'pbkdf2_sha256$600000$YEbqWCNJw5mPl0j9zVTjPa$x7DRBW71+/ULoSYvXG/UOwzJKHj/Eu7RZ6FahnH46QU=', '2026-05-23 17:15:53', '2026-09-09 12:49:20.768803', 0, 0, 1),
(8, 'sebastian', 'perez mena', '3168138251', 'melispapa@papa.com', 'pbkdf2_sha256$600000$BKUDzYOt3ge3ODsr9c6PWK$GpKEWwNzjrv/1C/mOFDmpcxIi9o++4Y6TotYpBB96lY=', '2026-05-27 10:09:29', '2026-06-30 07:40:26.243377', 0, 0, 1),
(9, 'samuel', 'perez', '3154840319', 'samuel@samuel.admin', '!IQqRyzp5p5SqwIXdHl3VqUpj8wEM9j8QCJYTeTw5', '2026-06-30 07:10:02', NULL, 0, 0, 1),
(10, 'admin', 'admin', '123356898765', 'admin@samuel.com', '!JdTsc7ufKlsnf7OF8nmPPhcSCOKgC3VeyCB2MRU7', '2026-06-30 07:12:48', NULL, 0, 0, 1),
(11, 'daniel', 'hernandez', '3011327929', 'agrosft84@gmail.com', 'pbkdf2_sha256$720000$94txEX6aJJIJb6WYDvNRvO$JJNC5gUi9HS+Wg19wocJMAfxwaAgU6L+F9F9sG7YAnE=', '2026-06-30 07:22:52', '2026-09-09 01:19:37.999021', 0, 0, 1),
(12, 'admin', 'admin', '', 'admin@agrosft.com', 'pbkdf2_sha256$1200000$00Ddyl1ARZ8F9oaixQkhtX$cDSk39yXMLuXMz8QkQRF5gYHPeNZVh0FKYPCZHlhngE=', '2026-09-09 16:22:45', '2026-09-09 11:25:08.351184', 1, 1, 1),
(13, 'daniel', 'hernandez', '', 'danibaron456@gmail.com', 'pbkdf2_sha256$1200000$NvDajhaBCaRrBGy7kQsmgb$cXuhidba1D1119IvHTGkfk/S/hMmJgkDGRqgisAXjqE=', '2026-09-09 16:27:37', '2026-09-14 01:20:18.461424', 0, 0, 1),
(14, 'Daniel david', 'Hernandez', '', 'danibaron446@gmail.com', 'pbkdf2_sha256$1200000$ABvjDqKPwKkTrJQNHdf2m0$rovMnHP+Y32RzQwDY/xgiHycI9O+g5LgSGQ8d5GCmiU=', '2026-09-09 17:47:13', '2026-09-09 12:51:54.450978', 0, 0, 1),
(15, 'sofia', 'alvarez', '', 'sofiaalvarezruiz279@gmail.com', 'pbkdf2_sha256$1200000$GqiPeL9usG9dPRDjEWpCXa$NRhWhLctjNHUxKnwR2yUfd26w76PcplYFqX7BKXeI4Q=', '2026-09-09 17:52:30', '2026-09-09 12:53:59.627321', 0, 0, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipo_movimiento`
--

CREATE TABLE `tipo_movimiento` (
  `id_tipo_movimiento` int(11) NOT NULL,
  `tipo_movimiento` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `tipo_movimiento`
--

INSERT INTO `tipo_movimiento` (`id_tipo_movimiento`, `tipo_movimiento`) VALUES
(1, 'compra'),
(2, 'venta'),
(3, 'vendida'),
(4, 'rechazada'),
(5, 'cancelada'),
(6, 'reabastecimiento');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `user_addresses`
--

CREATE TABLE `user_addresses` (
  `id_direccion` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `direccion` varchar(255) NOT NULL,
  `ciudad` varchar(100) NOT NULL,
  `departamento` varchar(100) NOT NULL,
  `codigo_postal` varchar(20) NOT NULL,
  `pais` varchar(100) NOT NULL,
  `es_principal` tinyint(1) NOT NULL DEFAULT 0,
  `fecha_creacion` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `fecha_actualizacion` datetime(6) NOT NULL DEFAULT current_timestamp(6)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `user_devices`
--

CREATE TABLE `user_devices` (
  `id_dispositivo` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `dispositivo_id` varchar(255) NOT NULL,
  `tipo_dispositivo` varchar(50) NOT NULL,
  `sistema_operativo` varchar(100) NOT NULL,
  `navegador` varchar(100) NOT NULL,
  `ultima_conexion` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `fecha_registro` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `esta_activo` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `user_profiles`
--

CREATE TABLE `user_profiles` (
  `id_perfil` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `imagen_perfil` varchar(255) DEFAULT NULL,
  `biografia` text DEFAULT NULL,
  `sitio_web` varchar(200) DEFAULT NULL,
  `telefono_contacto` varchar(20) DEFAULT NULL,
  `direccion_envio_predeterminada` text DEFAULT NULL,
  `fecha_creacion` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `fecha_actualizacion` datetime(6) NOT NULL DEFAULT current_timestamp(6) ON UPDATE current_timestamp(6),
  `notificaciones_activas` tinyint(1) NOT NULL DEFAULT 1,
  `idioma_preferido` varchar(10) NOT NULL DEFAULT 'es',
  `zona_horaria` varchar(50) NOT NULL DEFAULT 'America/Bogota'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `user_profiles`
--

INSERT INTO `user_profiles` (`id_perfil`, `id_usuario`, `imagen_perfil`, `biografia`, `sitio_web`, `telefono_contacto`, `direccion_envio_predeterminada`, `fecha_creacion`, `fecha_actualizacion`, `notificaciones_activas`, `idioma_preferido`, `zona_horaria`) VALUES
(1, 7, 'profile_pictures/IMG_20220727_181630213.jpg', NULL, NULL, NULL, NULL, '2026-06-25 05:27:17.947144', '2026-08-28 00:03:12.272702', 1, 'es', 'America/Bogota'),
(2, 11, '', NULL, NULL, NULL, NULL, '2026-06-30 02:24:46.764440', '2026-06-30 02:24:46.764474', 1, 'es', 'America/Bogota'),
(3, 8, '', NULL, NULL, NULL, NULL, '2026-06-30 07:40:26.844889', '2026-06-30 07:40:26.844963', 1, 'es', 'America/Bogota'),
(4, 12, '', NULL, NULL, NULL, NULL, '2026-09-09 11:23:08.400135', '2026-09-09 11:23:08.400176', 1, 'es', 'America/Bogota'),
(5, 13, '', NULL, NULL, NULL, NULL, '2026-09-09 11:27:37.937707', '2026-09-09 11:27:37.937868', 1, 'es', 'America/Bogota'),
(6, 14, '', NULL, NULL, NULL, NULL, '2026-09-09 12:47:13.623777', '2026-09-09 12:47:13.623804', 1, 'es', 'America/Bogota'),
(7, 15, '', NULL, NULL, NULL, NULL, '2026-09-09 12:52:30.218772', '2026-09-09 12:52:30.218842', 1, 'es', 'America/Bogota');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `auth_group`
--
ALTER TABLE `auth_group`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indices de la tabla `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  ADD KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`);

--
-- Indices de la tabla `auth_permission`
--
ALTER TABLE `auth_permission`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`);

--
-- Indices de la tabla `django_admin_log`
--
ALTER TABLE `django_admin_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  ADD KEY `django_admin_log_user_id_c564eba6_fk_tblusuarios_id_users` (`user_id`);

--
-- Indices de la tabla `django_content_type`
--
ALTER TABLE `django_content_type`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`);

--
-- Indices de la tabla `django_migrations`
--
ALTER TABLE `django_migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `django_session`
--
ALTER TABLE `django_session`
  ADD PRIMARY KEY (`session_key`),
  ADD KEY `django_session_expire_date_a5c62663` (`expire_date`);

--
-- Indices de la tabla `factura`
--
ALTER TABLE `factura`
  ADD PRIMARY KEY (`id_factura`),
  ADD KEY `factura_id_movimiento_1b262392_fk_movimiento_id_movimiento` (`id_movimiento`),
  ADD KEY `factura_id_usuario_d219effc_fk_tblusuarios_id_users` (`id_usuario`),
  ADD KEY `factura_id_vendedor_d64f33d3_fk_tblusuarios_id_users` (`id_vendedor`);

--
-- Indices de la tabla `item_factura`
--
ALTER TABLE `item_factura`
  ADD PRIMARY KEY (`id_item`),
  ADD KEY `item_factura_id_factura_be7a20d7_fk_factura_id_factura` (`id_factura`),
  ADD KEY `item_factura_id_producto_a2fc3180_fk_tblproducto_id_productos` (`id_producto`);

--
-- Indices de la tabla `movimiento`
--
ALTER TABLE `movimiento`
  ADD PRIMARY KEY (`id_movimiento`),
  ADD KEY `fk_movimiento_tipo_movimiento1_idx` (`tipo_movimiento_id_tipo_movimiento`),
  ADD KEY `fk_movimiento_tblusuarios1_idx` (`tblusuarios_id_users`);

--
-- Indices de la tabla `social_auth_association`
--
ALTER TABLE `social_auth_association`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `social_auth_association_server_url_handle_078befa2_uniq` (`server_url`,`handle`);

--
-- Indices de la tabla `social_auth_code`
--
ALTER TABLE `social_auth_code`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `social_auth_code_email_code_801b2d02_uniq` (`email`,`code`),
  ADD KEY `social_auth_code_code_a2393167` (`code`),
  ADD KEY `social_auth_code_timestamp_176b341f` (`timestamp`);

--
-- Indices de la tabla `social_auth_nonce`
--
ALTER TABLE `social_auth_nonce`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `social_auth_nonce_server_url_timestamp_salt_f6284463_uniq` (`server_url`,`timestamp`,`salt`);

--
-- Indices de la tabla `social_auth_partial`
--
ALTER TABLE `social_auth_partial`
  ADD PRIMARY KEY (`id`),
  ADD KEY `social_auth_partial_token_3017fea3` (`token`),
  ADD KEY `social_auth_partial_timestamp_50f2119f` (`timestamp`);

--
-- Indices de la tabla `social_auth_usersocialauth`
--
ALTER TABLE `social_auth_usersocialauth`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `social_auth_usersocialauth_provider_uid_e6b5e668_uniq` (`provider`,`uid`),
  ADD KEY `social_auth_usersoci_user_id_17d28448_fk_tblusuari` (`user_id`),
  ADD KEY `social_auth_usersocialauth_uid_796e51dc` (`uid`);

--
-- Indices de la tabla `tblcategoria`
--
ALTER TABLE `tblcategoria`
  ADD PRIMARY KEY (`idt_categoria`);

--
-- Indices de la tabla `tblproducto`
--
ALTER TABLE `tblproducto`
  ADD PRIMARY KEY (`id_productos`),
  ADD KEY `fk_tblproductos_tblcategoria_idx` (`tblcategoria_idt_categoria`),
  ADD KEY `fk_producto_unidad` (`unidad_medida_id`),
  ADD KEY `fk_tblproductos_tblunidad_medida` (`tblunidad_medida_id_unidad`);

--
-- Indices de la tabla `tblproductos_has_tblusuarios`
--
ALTER TABLE `tblproductos_has_tblusuarios`
  ADD PRIMARY KEY (`id_pd_us`),
  ADD KEY `fk_tblproductos_has_tblusuarios_tblusuarios1_idx` (`tblusuarios_id_users`),
  ADD KEY `fk_tblproductos_has_tblusuarios_tblproductos1_idx` (`tblproductos_id_productos`);

--
-- Indices de la tabla `tblproductos_has_tblusuarios_has_movimiento`
--
ALTER TABLE `tblproductos_has_tblusuarios_has_movimiento`
  ADD PRIMARY KEY (`id_movimiento_usuario`),
  ADD KEY `fk_tblproductos_has_tblusuarios_has_movimiento_movimiento1_idx` (`movimiento_id_movimiento`),
  ADD KEY `fk_tblproductos_has_tblusuarios_has_movimiento_tblproductos_idx` (`tblproductos_has_tblusuarios_id_pd_us`);

--
-- Indices de la tabla `tblproducto_imagenes`
--
ALTER TABLE `tblproducto_imagenes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_producto_imagenes_producto` (`id_producto`);

--
-- Indices de la tabla `tblunidad_medida`
--
ALTER TABLE `tblunidad_medida`
  ADD PRIMARY KEY (`id_unidad`),
  ADD UNIQUE KEY `nombre` (`nombre`),
  ADD UNIQUE KEY `abreviatura` (`abreviatura`);

--
-- Indices de la tabla `tblusuarios`
--
ALTER TABLE `tblusuarios`
  ADD PRIMARY KEY (`id_users`);

--
-- Indices de la tabla `tipo_movimiento`
--
ALTER TABLE `tipo_movimiento`
  ADD PRIMARY KEY (`id_tipo_movimiento`);

--
-- Indices de la tabla `user_addresses`
--
ALTER TABLE `user_addresses`
  ADD PRIMARY KEY (`id_direccion`),
  ADD KEY `id_usuario` (`id_usuario`);

--
-- Indices de la tabla `user_devices`
--
ALTER TABLE `user_devices`
  ADD PRIMARY KEY (`id_dispositivo`),
  ADD KEY `id_usuario` (`id_usuario`);

--
-- Indices de la tabla `user_profiles`
--
ALTER TABLE `user_profiles`
  ADD PRIMARY KEY (`id_perfil`),
  ADD UNIQUE KEY `id_usuario` (`id_usuario`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `auth_group`
--
ALTER TABLE `auth_group`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `auth_permission`
--
ALTER TABLE `auth_permission`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=113;

--
-- AUTO_INCREMENT de la tabla `django_admin_log`
--
ALTER TABLE `django_admin_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `django_content_type`
--
ALTER TABLE `django_content_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT de la tabla `django_migrations`
--
ALTER TABLE `django_migrations`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT de la tabla `factura`
--
ALTER TABLE `factura`
  MODIFY `id_factura` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de la tabla `item_factura`
--
ALTER TABLE `item_factura`
  MODIFY `id_item` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de la tabla `movimiento`
--
ALTER TABLE `movimiento`
  MODIFY `id_movimiento` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT de la tabla `social_auth_association`
--
ALTER TABLE `social_auth_association`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `social_auth_code`
--
ALTER TABLE `social_auth_code`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `social_auth_nonce`
--
ALTER TABLE `social_auth_nonce`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `social_auth_partial`
--
ALTER TABLE `social_auth_partial`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `social_auth_usersocialauth`
--
ALTER TABLE `social_auth_usersocialauth`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `tblcategoria`
--
ALTER TABLE `tblcategoria`
  MODIFY `idt_categoria` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `tblproducto`
--
ALTER TABLE `tblproducto`
  MODIFY `id_productos` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT de la tabla `tblproductos_has_tblusuarios`
--
ALTER TABLE `tblproductos_has_tblusuarios`
  MODIFY `id_pd_us` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT de la tabla `tblproductos_has_tblusuarios_has_movimiento`
--
ALTER TABLE `tblproductos_has_tblusuarios_has_movimiento`
  MODIFY `id_movimiento_usuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;

--
-- AUTO_INCREMENT de la tabla `tblproducto_imagenes`
--
ALTER TABLE `tblproducto_imagenes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `tblunidad_medida`
--
ALTER TABLE `tblunidad_medida`
  MODIFY `id_unidad` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `tblusuarios`
--
ALTER TABLE `tblusuarios`
  MODIFY `id_users` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT de la tabla `tipo_movimiento`
--
ALTER TABLE `tipo_movimiento`
  MODIFY `id_tipo_movimiento` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de la tabla `user_addresses`
--
ALTER TABLE `user_addresses`
  MODIFY `id_direccion` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `user_devices`
--
ALTER TABLE `user_devices`
  MODIFY `id_dispositivo` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `user_profiles`
--
ALTER TABLE `user_profiles`
  MODIFY `id_perfil` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  ADD CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  ADD CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`);

--
-- Filtros para la tabla `auth_permission`
--
ALTER TABLE `auth_permission`
  ADD CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`);

--
-- Filtros para la tabla `django_admin_log`
--
ALTER TABLE `django_admin_log`
  ADD CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  ADD CONSTRAINT `django_admin_log_user_id_c564eba6_fk_tblusuarios_id_users` FOREIGN KEY (`user_id`) REFERENCES `tblusuarios` (`id_users`);

--
-- Filtros para la tabla `factura`
--
ALTER TABLE `factura`
  ADD CONSTRAINT `factura_id_movimiento_1b262392_fk_movimiento_id_movimiento` FOREIGN KEY (`id_movimiento`) REFERENCES `movimiento` (`id_movimiento`),
  ADD CONSTRAINT `factura_id_usuario_d219effc_fk_tblusuarios_id_users` FOREIGN KEY (`id_usuario`) REFERENCES `tblusuarios` (`id_users`),
  ADD CONSTRAINT `factura_id_vendedor_d64f33d3_fk_tblusuarios_id_users` FOREIGN KEY (`id_vendedor`) REFERENCES `tblusuarios` (`id_users`);

--
-- Filtros para la tabla `item_factura`
--
ALTER TABLE `item_factura`
  ADD CONSTRAINT `item_factura_id_factura_be7a20d7_fk_factura_id_factura` FOREIGN KEY (`id_factura`) REFERENCES `factura` (`id_factura`),
  ADD CONSTRAINT `item_factura_id_producto_a2fc3180_fk_tblproducto_id_productos` FOREIGN KEY (`id_producto`) REFERENCES `tblproducto` (`id_productos`);

--
-- Filtros para la tabla `movimiento`
--
ALTER TABLE `movimiento`
  ADD CONSTRAINT `fk_movimiento_tblusuarios1` FOREIGN KEY (`tblusuarios_id_users`) REFERENCES `tblusuarios` (`id_users`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_movimiento_tipo_movimiento1` FOREIGN KEY (`tipo_movimiento_id_tipo_movimiento`) REFERENCES `tipo_movimiento` (`id_tipo_movimiento`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `social_auth_usersocialauth`
--
ALTER TABLE `social_auth_usersocialauth`
  ADD CONSTRAINT `social_auth_usersoci_user_id_17d28448_fk_tblusuari` FOREIGN KEY (`user_id`) REFERENCES `tblusuarios` (`id_users`);

--
-- Filtros para la tabla `tblproducto`
--
ALTER TABLE `tblproducto`
  ADD CONSTRAINT `fk_producto_unidad` FOREIGN KEY (`unidad_medida_id`) REFERENCES `tblunidad_medida` (`id_unidad`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_tblproductos_tblcategoria` FOREIGN KEY (`tblcategoria_idt_categoria`) REFERENCES `tblcategoria` (`idt_categoria`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_tblproductos_tblunidad_medida` FOREIGN KEY (`tblunidad_medida_id_unidad`) REFERENCES `tblunidad_medida` (`id_unidad`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `tblproductos_has_tblusuarios`
--
ALTER TABLE `tblproductos_has_tblusuarios`
  ADD CONSTRAINT `fk_tblproductos_has_tblusuarios_tblproductos1` FOREIGN KEY (`tblproductos_id_productos`) REFERENCES `tblproducto` (`id_productos`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_tblproductos_has_tblusuarios_tblusuarios1` FOREIGN KEY (`tblusuarios_id_users`) REFERENCES `tblusuarios` (`id_users`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `tblproductos_has_tblusuarios_has_movimiento`
--
ALTER TABLE `tblproductos_has_tblusuarios_has_movimiento`
  ADD CONSTRAINT `fk_tblproductos_has_tblusuarios_has_movimiento_movimiento1` FOREIGN KEY (`movimiento_id_movimiento`) REFERENCES `movimiento` (`id_movimiento`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_tblproductos_has_tblusuarios_has_movimiento_tblproductos_h1` FOREIGN KEY (`tblproductos_has_tblusuarios_id_pd_us`) REFERENCES `tblproductos_has_tblusuarios` (`id_pd_us`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `tblproducto_imagenes`
--
ALTER TABLE `tblproducto_imagenes`
  ADD CONSTRAINT `fk_producto_imagenes_producto` FOREIGN KEY (`id_producto`) REFERENCES `tblproducto` (`id_productos`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `user_addresses`
--
ALTER TABLE `user_addresses`
  ADD CONSTRAINT `user_addresses_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `tblusuarios` (`id_users`) ON DELETE CASCADE;

--
-- Filtros para la tabla `user_devices`
--
ALTER TABLE `user_devices`
  ADD CONSTRAINT `user_devices_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `tblusuarios` (`id_users`) ON DELETE CASCADE;

--
-- Filtros para la tabla `user_profiles`
--
ALTER TABLE `user_profiles`
  ADD CONSTRAINT `user_profiles_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `tblusuarios` (`id_users`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

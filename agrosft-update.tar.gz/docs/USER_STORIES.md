# USER_STORIES.md — AgroSFT

> Historias de usuario y criterios de aceptación.  
> Derivadas de [[REQUIREMENTS]] y análisis de código existente.  
> **Formato**: `Como [rol], quiero [acción], para [beneficio]`

---

## Épica 1: Gestión de Usuarios

### US-01: Registro de Usuario

**Como** visitante no registrado,  
**quiero** crear una cuenta con mis datos personales,  
**para** poder acceder al sistema y publicar/comprar productos.

**Requisitos relacionados**: [[REQUIREMENTS#RF-U01]]

**Criterios de Aceptación**:
- [x] Formulario solicita: nombres, apellidos, correo, teléfono, contraseña
- [x] Correo debe ser único en el sistema
- [x] Contraseña mínima de 8 caracteres
- [x] Al registrarse exitosamente, redirige al login
- [x] Mensaje de confirmación visible
- [x] Validación de formato de correo electrónico

**Implementación**: `apps/usuarios/controllers/auth_controller.py` → `RegistroView`  
**Template**: `templates/usuarios/registro.html`

---

### US-02: Inicio de Sesión

**Como** usuario registrado,  
**quiero** autenticarme con correo y contraseña,  
**para** acceder a las funcionalidades del sistema.

**Requisitos relacionados**: [[REQUIREMENTS#RF-U02]]

**Criterios de Aceptación**:
- [x] Formulario solicita correo y contraseña
- [x] Credenciales inválidas muestran mensaje de error
- [x] Usuario inactivo no puede iniciar sesión
- [x] Redirige al marketplace tras login exitoso
- [x] Soporte para parámetro `?next=` para redirección personalizada

**Implementación**: `apps/usuarios/controllers/auth_controller.py` → `LoginView`  
**Template**: `templates/usuarios/login.html`

---

### US-03: Cerrar Sesión

**Como** usuario autenticado,  
**quiero** cerrar sesión de forma segura,  
**para** proteger mi cuenta en dispositivos compartidos.

**Requisitos relacionados**: [[REQUIREMENTS#RF-U03]]

**Criterios de Aceptación**:
- [x] Cierra la sesión activa del usuario
- [x] Limpia datos de sesión
- [x] Redirige al login
- [x] Previene acceso a páginas protegidas tras cerrar sesión (NoCacheMiddleware)
- [x] Soporta tanto GET como POST

**Implementación**: `apps/usuarios/controllers/auth_controller.py` → `LogoutView`

---

### US-04: Editar Perfil

**Como** usuario autenticado,  
**quiero** ver y editar mi información de perfil,  
**para** mantener mis datos actualizados.

**Requisitos relacionados**: [[REQUIREMENTS#RF-U04]], [[REQUIREMENTS#RF-U09]]

**Criterios de Aceptación**:
- [x] Muestra nombres, apellidos, correo, teléfono
- [x] Permite actualizar datos personales
- [x] Permite subir imagen de perfil
- [x] Permite eliminar imagen de perfil
- [x] Responde tanto a requests normales como AJAX

**Implementación**: `apps/usuarios/controllers/auth_controller.py` → `PerfilView`  
**Template**: `templates/usuarios/perfil.html`

---

## Épica 2: Gestión de Inventario

### US-05: Publicar Producto

**Como** agricultor,  
**quiero** publicar un nuevo producto con precio y cantidad,  
**para** que otros usuarios puedan verlo y comprarlo.

**Requisitos relacionados**: [[REQUIREMENTS#RF-I01]], [[REQUIREMENTS#RF-I12]]

**Criterios de Aceptación**:
- [x] Formulario solicita: nombre, descripción, categoría, precio, cantidad, stock mínimo
- [x] La fotografía del producto es **obligatoria** (JPG/JPEG/PNG/WEBP, máx. 5MB); sin imagen el formulario no se guarda
- [x] Si el producto ya existe en el catálogo, reutiliza el registro maestro
- [x] Crea relación ProductoUsuario con estado "Pendiente"
- [x] Si cantidad > 0, registra movimiento inicial de stock
- [x] Redirige a Mi Inventario tras creación exitosa

**Implementación**: `apps/inventario/controllers/producto_controller.py` → `crear_producto()`

```mermaid
graph TD
    A[Formulario POST] --> B{Producto existe?}
    B -->|No| C[Crear Producto maestro]
    B -->|Sí| D[Reutilizar existente]
    C --> E[Crear ProductoUsuario estado=Pendiente]
    D --> E
    E --> F{Cantidad > 0?}
    F -->|Sí| G[Crear Movimiento + Detalle]
    F -->|No| H[Fin]
    G --> H
```

---

### US-06: Ver Mi Inventario

**Como** agricultor,  
**quiero** ver la lista de mis productos publicados,  
**para** gestionar mi oferta.

**Requisitos relacionados**: [[REQUIREMENTS#RF-I02]], [[REQUIREMENTS#RF-I11]]

**Criterios de Aceptación**:
- [x] Lista SOLO productos del usuario actual
- [x] Muestra nombre, precio, stock, estado, categoría
- [x] Botones de editar y eliminar por producto
- [x] Búsqueda por nombre
- [x] Filtro por categoría
- [x] Paginación de 10 productos por página
- [x] Componente Vue `InventarioApp.vue` para interactividad

**Implementación**: `apps/inventario/controllers/producto_controller.py` → `listar_productos()`  
**Frontend**: `frontend/src/inventario/InventarioApp.vue`

---

### US-07: Editar Producto

**Como** agricultor,  
**quiero** modificar los datos de mi producto,  
**para** actualizar precio, stock o estado.

**Requisitos relacionados**: [[REQUIREMENTS#RF-I03]]

**Criterios de Aceptación**:
- [x] Solo el dueño puede editar
- [x] Formulario precargado con datos actuales
- [x] **Nombre y categoría no son modificables** (se muestran solo lectura al editar)
- [x] La fotografía es obligatoria en edición cuando la publicación no tiene ninguna imagen registrada
- [x] La cantidad de stock se muestra como **número entero** (sin decimales ni `.00`)
- [x] No se puede reducir el stock: el input tiene `step="1"` y `min="<stock_actual>"`, y la validación JS impide ingresar un valor menor
- [x] Validación server-side: si `nuevo_stock < stock_actual` retorna mensaje de error y cancela la operación
- [x] Si la cantidad aumenta (`diferencia > 0`), registra un `Movimiento` de tipo **`reabastecimiento`** y su detalle (`cantidad = diferencia`)
- [x] No actualiza stock directamente (lo hace el trigger de BD `trg_actualizar_stock_oferta`)

**Implementación**: `apps/inventario/controllers/producto_controller.py` → `editar_producto()`

---

### US-08: Marketplace

**Como** comprador,  
**quiero** navegar por productos disponibles de otros agricultores,  
**para** seleccionar los que quiero comprar.

**Requisitos relacionados**: [[REQUIREMENTS#RF-I05]], [[REQUIREMENTS#RF-I10]]

**Criterios de Aceptación**:
- [x] Muestra SOLO productos de OTROS usuarios con estado "Aprobado"
- [x] Excluye productos del usuario actual
- [x] Muestra nombre, precio, stock, vendedor, categoría
- [x] Botón "Agregar al carrito" por producto
- [x] Búsqueda, filtros, ordenamiento
- [x] Paginación de 12 productos por página
- [x] Componente Vue `MarketApp.vue` para interactividad

**Implementación**: `apps/inventario/controllers/producto_controller.py` → `marketplace()`  
**Frontend**: `frontend/src/marketplace/MarketApp.vue`

---

### US-15: Fotografía de Producto

**Como** agricultor,  
**quiero** adjuntar una fotografía a mi producto,  
**para** que los compradores puedan verlo visualmente en el marketplace.

**Requisitos relacionados**: [[REQUIREMENTS#RF-I15]]

**Criterios de Aceptación**:
- [x] Formulario de crear/editar producto incluye campo de imagen (`enctype="multipart/form-data"`)
- [x] Acepta extensiones JPG, JPEG, PNG y WEBP
- [x] Rechaza archivos mayores a 5MB (validación server-side en formulario y modelo)
- [x] La imagen se almacena en `MEDIA_ROOT/productos/` y se sirve vía `MEDIA_URL /media/`
- [x] La imagen se muestra en marketplace, inventario, detalle y componentes Vue (`MarketApp.vue`, `InventarioApp.vue`)
- [x] Al reutilizar un producto del catálogo maestro, la imagen queda asociada a la publicación
- [x] La edición permite reemplazar la imagen mostrando la actual

**Implementación**: `apps/inventario/forms/producto_form.py`, `apps/inventario/controllers/producto_controller.py` → `crear_producto()` / `editar_producto()`  
**Modelo**: `apps.inventario.models.producto.Producto.imagen`

---

## Épica 3: Proceso de Compra

### US-09: Carrito de Compras

**Como** comprador,  
**quiero** agregar productos a un carrito y gestionarlos,  
**para** preparar mi solicitud de compra.

**Requisitos relacionados**: [[REQUIREMENTS#RF-V01]], [[REQUIREMENTS#RF-V02]], [[REQUIREMENTS#RF-V03]], [[REQUIREMENTS#RF-V04]]

**Criterios de Aceptación**:
- [x] Agregar producto con validación de stock
- [x] Cambiar cantidad con controles +/-
- [x] Eliminar productos individuales
- [x] Calcular total automáticamente
- [x] Persiste en sesión (sobrevive recargas, no DB)
- [x] Componente Vue `CarritoApp.vue`

**Implementación**: `apps/ventas/services/carrito_service.py`  
**Frontend**: `frontend/src/carrito/CarritoApp.vue`

---

### US-10: Crear Solicitud de Compra

**Como** comprador,  
**quiero** enviar una solicitud de compra al vendedor,  
**para** iniciar el proceso de transacción.

**Requisitos relacionados**: [[REQUIREMENTS#RF-V06]]

**Criterios de Aceptación**:
- [x] Checkout crea Movimiento de tipo "compra"
- [x] Crea ProductoUsuarioMovimiento por cada item con la cantidad
- [x] Trigger de BD descuenta stock automáticamente al registrar el movimiento de "compra"
- [x] Limpia el carrito tras checkout exitoso
- [x] Redirige a vista de solicitudes

**Implementación**: `apps/ventas/controllers/carrito_controller.py` → `checkout_carrito()`

---

### US-11: Gestionar Solicitudes (Vendedor)

**Como** vendedor,  
**quiero** ver, aceptar o rechazar solicitudes de compra sobre mis productos,  
**para** decidir qué transacciones completar.

**Requisitos relacionados**: [[REQUIREMENTS#RF-V07]], [[REQUIREMENTS#RF-V08]], [[REQUIREMENTS#RF-V09]], [[REQUIREMENTS#RF-V10]]

**Criterios de Aceptación**:
- [x] Lista solicitudes de compra ("compra") sobre MIS productos
- [x] Muestra datos del comprador (nombre, email, teléfono) y facilita contacto por WhatsApp
- [x] Coordinación de la entrega y el pago fuera de la plataforma
- [x] Frontend funcional y notificaciones para feedback
- [x] Permite proceder a calificar la transacción/vendedor después

**Implementación**: `apps/ventas/controllers/solicitud_controller.py`  
**Frontend**: `apps/ventas/templates/ventas/solicitudes/solicitud_list.html` (Django template)

---

### US-12: Calificar Transacción

**Como** comprador/vendedor,  
**quiero** calificar una transacción completada,  
**para** generar reputación del vendedor.

**Requisitos relacionados**: [[REQUIREMENTS#RF-V13]]

**Criterios de Aceptación**:
- [x] Calificación de 1.0 a 5.0 en pasos de 0.5
- [x] Solo puede calificar si participó en la transacción
- [x] Solo puede calificar una vez por transacción
- [x] Estrellas interactivas con hover (Vue)
- [x] Trigger de BD actualiza calificacion_promedio en ProductoUsuario

**Implementación**: `apps/ventas/controllers/calificacion_controller.py`  
**Frontend**: `frontend/src/calificaciones/CalificacionApp.vue`

---

## Épica 4: Historial de Clientes

### US-13: Ver Historial de Clientes

**Como** vendedor,  
**quiero** ver el historial de compradores que han interactuado con mis productos,  
**para** conocer mi base de clientes.

**Requisitos relacionados**: [[REQUIREMENTS#RF-C01]], [[REQUIREMENTS#RF-C02]]

**Criterios de Aceptación**:
- [x] Lista usuarios con movimientos de compra/venta
- [x] Muestra estadísticas: total movimientos, compras, ventas
- [x] Ordenados por actividad (más activos primero)
- [x] Detalle de cliente con historial de movimientos

**Implementación**: `apps/clientes/controllers/cliente_controller.py`

---

---

### US-14: Contactar Comprador por WhatsApp

**Como** vendedor,
**quiero** al aceptar una solicitud de compra ser dirigido automáticamente al chat de WhatsApp del comprador,
**para** coordinar rápidamente la entrega y el pago del producto.

**Requisitos relacionados**: [[REQUIREMENTS#RF-V18]], [[REQUIREMENTS#RF-V19]]

**Criterios de Aceptación**:
- [x] Al aceptar una solicitud, se muestra un modal con botón para abrir WhatsApp del comprador
- [x] El mensaje de WhatsApp incluye el ID de la solicitud y el nombre del vendedor
- [x] El número de teléfono del comprador es un enlace cliqueable a wa.me
- [x] El enlace de WhatsApp solo aparece cuando la solicitud está en estado "aceptada"
- [x] No requiere API key de WhatsApp — usa wa.me links
- [x] El modal se muestra automáticamente tras aceptar la solicitud

**Implementación**: `apps/ventas/controllers/solicitud_controller.py` → `aceptar_solicitud()`, `detalle_solicitud()`  
**Utility**: `core/utils/helpers.py` → `generar_whatsapp_link()`

---

### US-16: Comprobante y Factura en Módulo de Ventas

**Como** vendedor,  
**quiero** generar la factura en PDF de una venta registrada sobre mis productos,  
**para** disponer de un comprobante comercial formal de la venta con los datos del comprador y el detalle pactado.

**Requisitos relacionados**: [[REQUIREMENTS#RF-V20]], [[REQUIREMENTS#RF-F01]], [[REQUIREMENTS#RF-F02]]

**Criterios de Aceptación**:
- [x] Botón "Factura" con ícono y estilo uniforme accesible desde "Historial de Ventas" (`venta_list.html`)
- [x] Botón "Generar Factura" accesible en el encabezado del detalle de la venta (`venta_detail.html`)
- [x] Abre en pestaña nueva (`target="_blank"`) el PDF generado con `xhtml2pdf`
- [x] El controlador valida que el usuario sea el vendedor participante del movimiento o el comprador antes de autorizar
- [x] Reutiliza la factura existente del movimiento sin duplicar registros contables

**Implementación**: `apps/facturacion/controllers/factura_controller.py` → `generar_factura_pedido()`, `apps/facturacion/services/factura_service.py`  
**Frontend**: `apps/ventas/templates/ventas/venta_list.html`, `apps/ventas/templates/ventas/venta_detail.html`

---

### US-16: Galería de Múltiples Imágenes con Carrusel

**Como** agricultor,
**quiero** subir varias fotografías de un producto y explorarlas en un carrusel,
**para** que los compradores vean mi producto desde varios ángulos.

**Requisitos relacionados**: [[REQUIREMENTS#RF-I16]]

**Criterios de Aceptación**:
- [x] El formulario de crear/editar producto permite seleccionar múltiples archivos en el campo `imagen` (`MultipleFileField`, `multiple=True`)
- [x] La primera imagen enviada se guarda como portada en `tblproducto.imagen`
- [x] Las imágenes adicionales se registran en la tabla `tblproducto_imagenes` con orden secuencial
- [x] El carrusel se muestra en las tarjetas de `InventarioApp.vue` y `MarketApp.vue` como imágenes a 220px (`object-fit: cover`) con flechas, dots y contador de fotos
- [x] La vista de detalle (`Productosdetalles.html`) muestra un carrusel principal (380px) con tira de miniaturas interactivas
- [x] Se descartan las URLs duplicadas de la portada al construir el carrusel
- [x] Al editar, permite agregar nuevos archivos preservando la galería existente

**Implementación**: `apps.inventario/forms/producto_form.py` (`MultipleFileInput`/`MultipleFileField`), `apps.inventario/controllers/producto_controller.py` → `crear_producto()` / `editar_producto()`, `Producto.get_imagenes()`
**Modelo**: `apps.inventario.models.producto.ProductoImagen` (tabla `tblproducto_imagenes`)

---

## Resumen de Historias por Estado

| Estado | Cantidad | Historias |
|---|---|---|
| ✅ Completadas | 14 | US-01 a US-14 |
| 🔶 Parciales | 2 | RF-U08 (password reset), RF-I13 (stock alerts) |
| ❌ No iniciadas | 8 | GAP-01 a GAP-08 (ver [[REQUIREMENTS#3. Requisitos Pendientes]]) |

---

## Enlaces Relacionados

- [[PROJECT_CONTEXT]] — Contexto global del proyecto
- [[REQUIREMENTS]] — Requisitos funcionales y no funcionales
- [[ARCHITECTURE]] — Cómo los módulos implementan estas historias
- [[API]] — Endpoints que soportan estas historias

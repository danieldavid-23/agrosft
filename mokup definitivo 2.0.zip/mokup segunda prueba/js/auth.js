// Funciones de autenticación
function login(email, password) {
    if (email && password) {
        // En una aplicación real, aquí se verificarían las credenciales con el servidor
        appState.user = {
            name: 'Usuario Demo',
            email: email,
            phone: '+57 123 456 7890',
            registrationDate: new Date().toLocaleDateString('es-ES')
        };
        
        updateAuthButtons();
        loginModal.style.display = 'none';
        authRequired.style.display = 'none';
        
        saveToLocalStorage();
        
        alert('¡Inicio de sesión exitoso!');
    } else {
        alert('Por favor, complete todos los campos');
    }
}

function register(name, email, phone, password) {
    if (name && email && phone && password) {
        // Obtener la foto de perfil si se subió
        let profilePictureData = null;
        if (fileInput.files.length > 0) {
            const file = fileInput.files[0];
            const reader = new FileReader();
            reader.onload = function(e) {
                profilePictureData = e.target.result;
                completeRegistration(name, email, phone, password, profilePictureData);
            };
            reader.readAsDataURL(file);
        } else {
            completeRegistration(name, email, phone, password, null);
        }
    } else {
        alert('Por favor, complete todos los campos');
    }
}

function completeRegistration(name, email, phone, password, profilePicture) {
    appState.user = {
        name: name,
        email: email,
        phone: phone,
        profilePicture: profilePicture,
        registrationDate: new Date().toLocaleDateString('es-ES')
    };
    
    updateAuthButtons();
    registerModal.style.display = 'none';
    authRequired.style.display = 'none';
    
    saveToLocalStorage();
    
    alert('¡Registro exitoso! Bienvenido a AgroMarket');
}

function logout() {
    appState.user = null;
    updateAuthButtons();
    saveToLocalStorage();
    alert('Sesión cerrada correctamente');
}

function showAuthRequired() {
    authRequired.style.display = 'flex';
}

// Actualizar botones de autenticación
function updateAuthButtons() {
    if (appState.user) {
        const avatarContent = appState.user.profilePicture ? 
            `<img src="${appState.user.profilePicture}" alt="${appState.user.name}">` : 
            appState.user.name.charAt(0);
        
        authButtons.innerHTML = `
            <div class="user-info">
                <div class="user-avatar">${avatarContent}</div>
                <span>Hola, ${appState.user.name.split(' ')[0]}</span>
            </div>
            <div class="cart-icon" id="cart-icon">
                🛒
                <span class="cart-count" id="cart-count">${appState.cart.reduce((total, item) => total + item.quantity, 0)}</span>
            </div>
            <button class="btn btn-outline" id="logout-btn">Cerrar Sesión</button>
        `;
        
        dashboard.style.display = 'block';
    } else {
        authButtons.innerHTML = `
            <button class="btn btn-outline" id="login-btn">Iniciar Sesión</button>
            <button class="btn btn-primary" id="register-btn">Registrarse</button>
        `;
        dashboard.style.display = 'none';
    }
}

// Configurar listeners de autenticación
function setupAuthListeners() {
    loginForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const email = document.getElementById('login-email').value;
        const password = document.getElementById('login-password').value;
        login(email, password);
    });

    registerForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const name = document.getElementById('register-name').value;
        const email = document.getElementById('register-email').value;
        const phone = document.getElementById('register-phone').value;
        const password = document.getElementById('register-password').value;
        const confirmPassword = document.getElementById('register-confirm-password').value;
        
        if (password !== confirmPassword) {
            alert('Las contraseñas no coinciden');
            return;
        }
        
        register(name, email, phone, password);
    });
}

// Configurar sistema de registro mejorado
function setupRegistrationListeners() {
    // Abrir selector de archivos al hacer clic en el botón de subir
    uploadBtn.addEventListener('click', () => {
        fileInput.click();
    });
    
    // Manejar la selección de archivo
    fileInput.addEventListener('change', (e) => {
        const file = e.target.files[0];
        
        if (file) {
            handleImageUpload(file, profileImage, placeholder);
        }
    });
    
    // Abrir modal de términos y condiciones
    readTermsLink.addEventListener('click', () => {
        switchTab('terms');
        profileModal.style.display = 'flex';
    });
    
    // Habilitar/deshabilitar botón de envío según aceptación de términos
    acceptTerms.addEventListener('change', () => {
        submitBtn.disabled = !acceptTerms.checked;
    });
    
    // Inicializar botón de envío como deshabilitado
    submitBtn.disabled = true;
}

// Manejar subida de imágenes
function handleImageUpload(file, imageElement, placeholderElement) {
    // Validar tipo de archivo
    const validTypes = ['image/jpeg', 'image/png', 'image/gif'];
    if (!validTypes.includes(file.type)) {
        alert('Por favor, selecciona una imagen válida (JPG, PNG o GIF).');
        return;
    }
    
    // Validar tamaño de archivo (5MB máximo)
    if (file.size > 5 * 1024 * 1024) {
        alert('La imagen es demasiado grande. El tamaño máximo permitido es 5MB.');
        return;
    }
    
    // Crear objeto URL para la imagen
    const imageURL = URL.createObjectURL(file);
    
    // Mostrar la imagen
    imageElement.src = imageURL;
    imageElement.style.display = 'block';
    if (placeholderElement) {
        placeholderElement.style.display = 'none';
    }
}
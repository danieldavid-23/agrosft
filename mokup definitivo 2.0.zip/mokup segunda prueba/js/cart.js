// Funciones del carrito
function addToCart(productId) {
    const product = appState.products.find(p => p.id === productId);
    
    if (!product) return;
    
    // Verificación: Si el usuario actual es el vendedor, no permitir agregar al carrito
    if (appState.user && product.seller === appState.user.email) {
        alert('No puedes agregar tus propios productos al carrito');
        return;
    }
    
    if (product.stock <= 0) {
        alert('Lo sentimos, este producto no tiene stock disponible');
        return;
    }
    
    const existingItem = appState.cart.find(item => item.id === productId);
    
    if (existingItem) {
        if (existingItem.quantity >= product.stock) {
            alert('No hay suficiente stock disponible');
            return;
        }
        existingItem.quantity += 1;
    } else {
        appState.cart.push({
            id: product.id,
            name: product.name,
            price: product.price,
            image: product.images && product.images.length > 0 ? product.images[0] : '🌱',
            quantity: 1,
            seller: product.seller
        });
    }
    
    updateCartCount();
    saveToLocalStorage();
    alert(`¡${product.name} agregado al carrito!`);
}

function updateCartCount() {
    const cartCount = document.getElementById('cart-count');
    if (cartCount) {
        cartCount.textContent = appState.cart.reduce((total, item) => total + item.quantity, 0);
    }
}

function openCart() {
    if (!appState.user) {
        showAuthRequired();
        return;
    }
    renderCartItems();
    cartModal.style.display = 'flex';
}

function renderCartItems() {
    cartItems.innerHTML = '';
    
    if (appState.cart.length === 0) {
        cartItems.innerHTML = '<p style="text-align: center; padding: 2rem;">Tu carrito está vacío</p>';
        cartTotal.textContent = '0';
        return;
    }
    
    let total = 0;
    
    appState.cart.forEach(item => {
        const itemTotal = item.price * item.quantity;
        total += itemTotal;
        
        const cartItem = document.createElement('div');
        cartItem.className = 'cart-item';
        cartItem.innerHTML = `
            <div class="cart-item-info">
                <div class="cart-item-image">
                    <span style="font-size: 2rem;">${item.image}</span>
                </div>
                <div class="cart-item-details">
                    <h4>${item.name}</h4>
                    <div class="cart-item-price">$${item.price.toLocaleString()} / kg</div>
                </div>
            </div>
            <div class="cart-item-actions">
                <div class="cart-item-quantity">
                    <button class="quantity-btn minus" data-id="${item.id}">-</button>
                    <input type="text" class="quantity-input" value="${item.quantity}" readonly>
                    <button class="quantity-btn plus" data-id="${item.id}">+</button>
                </div>
                <div style="margin-top: 10px;">
                    <button class="btn btn-outline remove-item" data-id="${item.id}">Eliminar</button>
                </div>
            </div>
        `;
        
        cartItems.appendChild(cartItem);
    });
    
    cartTotal.textContent = total.toLocaleString();
    
    // Event listeners para los botones de cantidad
    document.querySelectorAll('.quantity-btn.minus').forEach(button => {
        button.addEventListener('click', (e) => {
            const productId = parseInt(e.target.getAttribute('data-id'));
            updateCartItemQuantity(productId, -1);
        });
    });
    
    document.querySelectorAll('.quantity-btn.plus').forEach(button => {
        button.addEventListener('click', (e) => {
            const productId = parseInt(e.target.getAttribute('data-id'));
            updateCartItemQuantity(productId, 1);
        });
    });
    
    document.querySelectorAll('.remove-item').forEach(button => {
        button.addEventListener('click', (e) => {
            const productId = parseInt(e.target.getAttribute('data-id'));
            removeFromCart(productId);
        });
    });
}

function updateCartItemQuantity(productId, change) {
    const item = appState.cart.find(item => item.id === productId);
    
    if (!item) return;
    
    const newQuantity = item.quantity + change;
    
    if (newQuantity <= 0) {
        removeFromCart(productId);
    } else {
        item.quantity = newQuantity;
        updateCartCount();
        saveToLocalStorage();
        renderCartItems();
    }
}

function removeFromCart(productId) {
    appState.cart = appState.cart.filter(item => item.id !== productId);
    updateCartCount();
    saveToLocalStorage();
    renderCartItems();
}

function checkout() {
    if (appState.cart.length === 0) {
        alert('Tu carrito está vacío');
        return;
    }
    
    // Simular proceso de compra
    alert('¡Compra realizada con éxito! Serás redirigido al proceso de pago.');
    appState.cart = [];
    updateCartCount();
    cartModal.style.display = 'none';
    renderCartItems();
}

// Configurar listeners del carrito
function setupCartListeners() {
    checkoutBtn.addEventListener('click', checkout);
}
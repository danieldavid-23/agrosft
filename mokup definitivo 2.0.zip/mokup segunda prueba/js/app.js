// Elementos del DOM - Variables globales
const authButtons = document.getElementById('auth-buttons');
const productsGrid = document.getElementById('products-grid');
const loginModal = document.getElementById('login-modal');
const registerModal = document.getElementById('register-modal');
const addProductModal = document.getElementById('add-product-modal');
const inventoryModal = document.getElementById('inventory-modal');
const profileModal = document.getElementById('profile-modal');
const cartModal = document.getElementById('cart-modal');
const authRequired = document.getElementById('auth-required');
const cartItems = document.getElementById('cart-items');
const cartTotal = document.getElementById('cart-total');
const closeModalBtns = document.querySelectorAll('.close-modal');
const switchToRegister = document.getElementById('switch-to-register');
const switchToLogin = document.getElementById('switch-to-login');
const loginForm = document.getElementById('login-form');
const registerForm = document.getElementById('register-form');
const addProductForm = document.getElementById('add-product-form');
const exploreBtn = document.getElementById('explore-btn');
const closeCartBtn = document.getElementById('close-cart');
const checkoutBtn = document.getElementById('checkout-btn');
const authLoginBtn = document.getElementById('auth-login-btn');
const authRegisterBtn = document.getElementById('auth-register-btn');
const dashboard = document.getElementById('dashboard');
const addProductCard = document.getElementById('add-product-card');
const inventoryCard = document.getElementById('inventory-card');
const profileCard = document.getElementById('profile-card');
const termsCard = document.getElementById('terms-card');
const cancelAddProduct = document.getElementById('cancel-add-product');
const userProductsList = document.getElementById('user-products-list');
const goToAddProduct = document.getElementById('go-to-add-product');

// Elementos del DOM para el sistema de registro mejorado
const uploadBtn = document.getElementById('uploadBtn');
const fileInput = document.getElementById('fileInput');
const profileImage = document.getElementById('profileImage');
const profilePicture = document.getElementById('profilePicture');
const placeholder = document.querySelector('.placeholder');
const readTermsLink = document.getElementById('readTerms');
const acceptTerms = document.getElementById('terms-checkbox');
const submitBtn = document.getElementById('submitBtn');

// Elementos del DOM para el perfil
const currentProfileImage = document.getElementById('currentProfileImage');
const currentPlaceholder = document.getElementById('currentPlaceholder');
const currentProfilePicture = document.getElementById('currentProfilePicture');
const editProfileImage = document.getElementById('editProfileImage');
const editProfilePicture = document.getElementById('editProfilePicture');
const editFileInput = document.getElementById('editFileInput');
const editUploadBtn = document.getElementById('editUploadBtn');
const savePhotoBtn = document.getElementById('savePhotoBtn');
const profileName = document.getElementById('profile-name');
const profileEmail = document.getElementById('profile-email');
const profilePhone = document.getElementById('profile-phone');
const profileDate = document.getElementById('profile-date');

// Estado de la aplicación
const appState = {
    user: null,
    cart: [],
    products: [
        {
            id: 1,
            name: "Maíz Amarillo Premium",
            price: 25000,
            description: "Maíz de alta calidad, cultivado de forma sostenible en el Valle del Cauca.",
            location: "Valle del Cauca",
            category: "cereales",
            stock: 500,
            rating: 4.8,
            reviews: 24,
            images: ["🌽"],
            seller: "system",
            sellerName: "Sistema AgroMarket"
        },
        {
            id: 2,
            name: "Papa Criolla Fresca",
            price: 3500,
            description: "Papa criolla recién cosechada, ideal para sus preparaciones tradicionales.",
            location: "Cundinamarca",
            category: "tuberculos",
            stock: 200,
            rating: 4.6,
            reviews: 18,
            images: ["🥔"],
            seller: "system",
            sellerName: "Sistema AgroMarket"
        },
        {
            id: 3,
            name: "Plátano Verde",
            price: 1800,
            description: "Plátano verde de excelente calidad, directo de nuestras fincas certificadas.",
            location: "Eje Cafetero",
            category: "frutas",
            stock: 300,
            rating: 4.9,
            reviews: 32,
            images: ["🍌"],
            seller: "system",
            sellerName: "Sistema AgroMarket"
        }
    ],
    userProducts: []
};

// Inicializar la aplicación
function initApp() {
    loadFromLocalStorage();
    updateAuthButtons();
    renderProducts();
    updateCartCount();
    setupEventListeners();
    setupAuthListeners();
    setupProductListeners();
    setupCartListeners();
    setupUIListeners();
    setupRegistrationListeners();
    
    if (appState.user) {
        loadUserProfile();
    }
}

// Cargar datos del localStorage
function loadFromLocalStorage() {
    const savedUser = localStorage.getItem('agromarket_user');
    const savedCart = localStorage.getItem('agromarket_cart');
    const savedProducts = localStorage.getItem('agromarket_products');
    const savedUserProducts = localStorage.getItem('agromarket_user_products');
    
    if (savedUser) appState.user = JSON.parse(savedUser);
    if (savedCart) appState.cart = JSON.parse(savedCart);
    if (savedProducts) appState.products = JSON.parse(savedProducts);
    if (savedUserProducts) appState.userProducts = JSON.parse(savedUserProducts);
}

// Guardar datos en localStorage
function saveToLocalStorage() {
    localStorage.setItem('agromarket_user', JSON.stringify(appState.user));
    localStorage.setItem('agromarket_cart', JSON.stringify(appState.cart));
    localStorage.setItem('agromarket_products', JSON.stringify(appState.products));
    localStorage.setItem('agromarket_user_products', JSON.stringify(appState.userProducts));
}

// Configurar event listeners generales
function setupEventListeners() {
    // Event listeners para categorías
    document.querySelectorAll('.category-card').forEach(card => {
        card.addEventListener('click', () => {
            const category = card.getAttribute('data-category');
            filterProductsByCategory(category);
        });
    });

    // Event listeners para botones de autenticación (delegación de eventos)
    document.addEventListener('click', function(e) {
        if (e.target.id === 'login-btn') {
            loginModal.style.display = 'flex';
        }
        if (e.target.id === 'register-btn') {
            registerModal.style.display = 'flex';
        }
        if (e.target.id === 'logout-btn') {
            logout();
        }
        if (e.target.id === 'cart-icon' || e.target.closest('#cart-icon')) {
            openCart();
        }
    });

    // Event listeners para tarjetas del dashboard
    addProductCard.addEventListener('click', () => {
        if (!appState.user) {
            showAuthRequired();
            return;
        }
        addProductModal.style.display = 'flex';
    });

    inventoryCard.addEventListener('click', () => {
        if (!appState.user) {
            showAuthRequired();
            return;
        }
        inventoryModal.style.display = 'flex';
        renderUserProducts();
    });

    profileCard.addEventListener('click', () => {
        if (!appState.user) {
            showAuthRequired();
            return;
        }
        profileModal.style.display = 'flex';
        loadUserProfile();
    });

    termsCard.addEventListener('click', () => {
        if (!appState.user) {
            showAuthRequired();
            return;
        }
        profileModal.style.display = 'flex';
        switchTab('terms');
    });

    // Event listeners para footer
    document.getElementById('footer-add-product').addEventListener('click', (e) => {
        e.preventDefault();
        if (!appState.user) {
            showAuthRequired();
            return;
        }
        addProductModal.style.display = 'flex';
    });

    document.getElementById('footer-inventory').addEventListener('click', (e) => {
        e.preventDefault();
        if (!appState.user) {
            showAuthRequired();
            return;
        }
        inventoryModal.style.display = 'flex';
        renderUserProducts();
    });

    document.getElementById('footer-profile').addEventListener('click', (e) => {
        e.preventDefault();
        if (!appState.user) {
            showAuthRequired();
            return;
        }
        profileModal.style.display = 'flex';
        loadUserProfile();
    });

    document.getElementById('footer-terms').addEventListener('click', (e) => {
        e.preventDefault();
        if (!appState.user) {
            showAuthRequired();
            return;
        }
        profileModal.style.display = 'flex';
        switchTab('terms');
    });

    // Event listeners para modales
    closeModalBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            loginModal.style.display = 'none';
            registerModal.style.display = 'none';
            addProductModal.style.display = 'none';
            inventoryModal.style.display = 'none';
            profileModal.style.display = 'none';
            cartModal.style.display = 'none';
        });
    });

    switchToRegister.addEventListener('click', (e) => {
        e.preventDefault();
        loginModal.style.display = 'none';
        registerModal.style.display = 'flex';
    });

    switchToLogin.addEventListener('click', (e) => {
        e.preventDefault();
        registerModal.style.display = 'none';
        loginModal.style.display = 'flex';
    });

    exploreBtn.addEventListener('click', () => {
        document.getElementById('productos').scrollIntoView({ behavior: 'smooth' });
    });

    closeCartBtn.addEventListener('click', () => {
        cartModal.style.display = 'none';
    });

    authLoginBtn.addEventListener('click', () => {
        authRequired.style.display = 'none';
        loginModal.style.display = 'flex';
    });

    authRegisterBtn.addEventListener('click', () => {
        authRequired.style.display = 'none';
        registerModal.style.display = 'flex';
    });

    // Cerrar modales al hacer clic fuera
    window.addEventListener('click', (e) => {
        if (e.target === loginModal) loginModal.style.display = 'none';
        if (e.target === registerModal) registerModal.style.display = 'none';
        if (e.target === addProductModal) addProductModal.style.display = 'none';
        if (e.target === inventoryModal) inventoryModal.style.display = 'none';
        if (e.target === profileModal) profileModal.style.display = 'none';
        if (e.target === cartModal) cartModal.style.display = 'none';
        if (e.target === authRequired) authRequired.style.display = 'none';
    });
}

// Inicializar la aplicación cuando el DOM esté listo
document.addEventListener('DOMContentLoaded', initApp);
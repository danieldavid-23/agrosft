// Funciones de interfaz de usuario
function loadUserProfile() {
    if (appState.user) {
        // Actualizar información del perfil
        profileName.textContent = appState.user.name;
        profileEmail.textContent = appState.user.email;
        profilePhone.textContent = appState.user.phone;
        profileDate.textContent = appState.user.registrationDate || 'No disponible';
        
        // Actualizar foto de perfil
        if (appState.user.profilePicture) {
            currentProfileImage.src = appState.user.profilePicture;
            currentProfileImage.style.display = 'block';
            currentPlaceholder.style.display = 'none';
            
            editProfileImage.src = appState.user.profilePicture;
            editProfileImage.style.display = 'block';
            editProfilePicture.querySelector('.placeholder').style.display = 'none';
        } else {
            currentProfileImage.style.display = 'none';
            currentPlaceholder.style.display = 'block';
            
            editProfileImage.style.display = 'none';
            editProfilePicture.querySelector('.placeholder').style.display = 'block';
        }
    }
}

function updateProfileDisplay() {
    // Actualizar avatar en el header
    updateAuthButtons();
    
    // Actualizar foto en el modal de perfil
    loadUserProfile();
}

function switchTab(tabId) {
    // Ocultar todas las pestañas
    document.querySelectorAll('.tab').forEach(tab => {
        tab.classList.remove('active');
    });
    
    document.querySelectorAll('.tab-content').forEach(content => {
        content.classList.remove('active');
    });
    
    // Activar la pestaña seleccionada
    document.querySelector(`.tab[data-tab="${tabId}"]`).classList.add('active');
    document.getElementById(`${tabId}-tab`).classList.add('active');
}

// Configurar listeners de la interfaz de usuario
function setupUIListeners() {
    // Configurar pestañas del perfil
    document.querySelectorAll('.tab').forEach(tab => {
        tab.addEventListener('click', () => {
            const tabId = tab.getAttribute('data-tab');
            switchTab(tabId);
        });
    });
    
    // Configurar gestión de perfil
    setupProfileListeners();
}

// Configurar gestión de perfil
function setupProfileListeners() {
    // Abrir selector de archivos para editar foto
    editUploadBtn.addEventListener('click', () => {
        editFileInput.click();
    });
    
    // Manejar la selección de archivo para editar
    editFileInput.addEventListener('change', (e) => {
        const file = e.target.files[0];
        
        if (file) {
            handleImageUpload(file, editProfileImage, editProfilePicture.querySelector('.placeholder'));
        }
    });
    
    // Guardar cambios de foto
    savePhotoBtn.addEventListener('click', () => {
        if (editFileInput.files.length > 0) {
            const file = editFileInput.files[0];
            const reader = new FileReader();
            reader.onload = function(e) {
                appState.user.profilePicture = e.target.result;
                saveToLocalStorage();
                updateProfileDisplay();
                alert('Foto de perfil actualizada correctamente');
            };
            reader.readAsDataURL(file);
        } else {
            alert('Por favor, selecciona una nueva foto de perfil');
        }
    });
}
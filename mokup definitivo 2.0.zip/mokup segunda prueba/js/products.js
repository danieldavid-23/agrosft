// Funciones de gestión de productos
function renderProducts(productsToRender = appState.products) {
    productsGrid.innerHTML = '';
    
    if (productsToRender.length === 0) {
        productsGrid.innerHTML = '<p style="text-align: center; grid-column: 1 / -1; padding: 2rem;">No se encontraron productos</p>';
        return;
    }
    
    productsToRender.forEach(product => {
        const isOwnProduct = appState.user && product.seller === appState.user.email;
        const buttonText = isOwnProduct ? 'Mi Producto' : (product.stock <= 0 ? 'Sin Stock' : 'Agregar al Carrito');
        const isButtonDisabled = isOwnProduct || product.stock <= 0;
        
        const productCard = document.createElement('div');
        productCard.className = 'product-card';
        productCard.innerHTML = `
            <div class="product-image">
                ${product.images && product.images.length > 0 ? 
                    `<span style="font-size: 3rem;">${product.images[0]}</span>` : 
                    '<span style="font-size: 3rem;">🌱</span>'
                }
            </div>
            <div class="product-info">
                <h3 class="product-title">${product.name}</h3>
                <div class="product-price">$${product.price.toLocaleString()} / kg</div>
                <p class="product-description">${product.description}</p>
                <div class="product-meta">
                    <span>📍 ${product.location}</span>
                    <span>⭐ ${product.rating} (${product.reviews})</span>
                </div>
                <div class="product-meta">
                    <span>Vendedor: ${product.sellerName || 'AgroMarket'}</span>
                    <span>Stock: ${product.stock} kg</span>
                </div>
                <div class="product-actions">
                    <button class="btn-add-cart" data-id="${product.id}" ${isButtonDisabled ? 'disabled' : ''}>
                        ${buttonText}
                    </button>
                </div>
            </div>
        `;
        
        productsGrid.appendChild(productCard);
    });
    
    // Agregar event listeners a los botones de carrito
    document.querySelectorAll('.btn-add-cart').forEach(button => {
        button.addEventListener('click', (e) => {
            if (!appState.user) {
                showAuthRequired();
                return;
            }
            
            const productId = parseInt(e.target.getAttribute('data-id'));
            addToCart(productId);
        });
    });
}

function filterProductsByCategory(category) {
    const filteredProducts = appState.products.filter(product => 
        product.category === category
    );
    renderProducts(filteredProducts);
}

// Gestión de productos del usuario
function handleAddProduct() {
    const name = document.getElementById('product-name').value;
    const description = document.getElementById('product-description').value;
    const price = parseFloat(document.getElementById('product-price').value);
    const category = document.getElementById('product-category').value;
    const location = document.getElementById('product-location').value;
    const stock = parseFloat(document.getElementById('product-stock').value);
    
    const newProduct = {
        id: Date.now(),
        name,
        description,
        price,
        category,
        location,
        stock,
        images: ['🌱'],
        rating: 0,
        reviews: 0,
        seller: appState.user.email,
        sellerName: appState.user.name,
        sold: 0,
        orders: 0
    };
    
    appState.userProducts.push(newProduct);
    appState.products.push(newProduct);
    
    saveToLocalStorage();
    
    addProductModal.style.display = 'none';
    addProductForm.reset();
    
    alert(`¡Producto "${name}" registrado exitosamente!`);
    
    renderProducts();
}

function renderUserProducts() {
    userProductsList.innerHTML = '';
    
    if (appState.userProducts.length === 0) {
        userProductsList.innerHTML = '<p style="text-align: center; padding: 2rem;">No has registrado productos aún</p>';
        return;
    }
    
    appState.userProducts.forEach(product => {
        const productItem = document.createElement('div');
        productItem.className = 'inventory-item';
        productItem.innerHTML = `
            <div class="inventory-item-header">
                <h3>${product.name}</h3>
                <div class="inventory-item-actions">
                    <button class="btn btn-outline edit-product" data-id="${product.id}">Editar</button>
                    <button class="btn btn-danger delete-product" data-id="${product.id}">Eliminar</button>
                </div>
            </div>
            <p>${product.description}</p>
            <div class="product-meta">
                <span>Precio: $${product.price.toLocaleString()} / kg</span>
                <span>Categoría: ${product.category}</span>
            </div>
            <div class="inventory-stats">
                <div class="stat">
                    <div class="stat-value">${product.stock}</div>
                    <div class="stat-label">Stock (kg)</div>
                </div>
                <div class="stat">
                    <div class="stat-value">${product.sold || 0}</div>
                    <div class="stat-label">Vendidos (kg)</div>
                </div>
                <div class="stat">
                    <div class="stat-value">${product.orders || 0}</div>
                    <div class="stat-label">Pedidos</div>
                </div>
                <div class="stat">
                    <div class="stat-value">${product.rating || 0}</div>
                    <div class="stat-label">Rating</div>
                </div>
            </div>
        `;
        
        userProductsList.appendChild(productItem);
    });
    
    document.querySelectorAll('.edit-product').forEach(button => {
        button.addEventListener('click', (e) => {
            const productId = parseInt(e.target.getAttribute('data-id'));
            editProduct(productId);
        });
    });
    
    document.querySelectorAll('.delete-product').forEach(button => {
        button.addEventListener('click', (e) => {
            const productId = parseInt(e.target.getAttribute('data-id'));
            deleteProduct(productId);
        });
    });
}

function editProduct(productId) {
    const product = appState.userProducts.find(p => p.id === productId);
    if (!product) return;
    
    document.getElementById('product-name').value = product.name;
    document.getElementById('product-description').value = product.description;
    document.getElementById('product-price').value = product.price;
    document.getElementById('product-category').value = product.category;
    document.getElementById('product-location').value = product.location;
    document.getElementById('product-stock').value = product.stock;
    
    addProductModal.style.display = 'flex';
    
    // Cambiar el comportamiento del formulario para actualizar
    const submitBtn = addProductForm.querySelector('button[type="submit"]');
    submitBtn.textContent = 'Actualizar Producto';
    submitBtn.setAttribute('data-edit-id', productId);
    
    addProductForm.removeEventListener('submit', handleAddProduct);
    addProductForm.addEventListener('submit', (e) => {
        e.preventDefault();
        updateProduct(productId);
    });
}

function updateProduct(productId) {
    const productIndex = appState.userProducts.findIndex(p => p.id === productId);
    if (productIndex === -1) return;
    
    const name = document.getElementById('product-name').value;
    const description = document.getElementById('product-description').value;
    const price = parseFloat(document.getElementById('product-price').value);
    const category = document.getElementById('product-category').value;
    const location = document.getElementById('product-location').value;
    const stock = parseFloat(document.getElementById('product-stock').value);
    
    appState.userProducts[productIndex] = {
        ...appState.userProducts[productIndex],
        name,
        description,
        price,
        category,
        location,
        stock
    };
    
    const generalProductIndex = appState.products.findIndex(p => p.id === productId);
    if (generalProductIndex !== -1) {
        appState.products[generalProductIndex] = {
            ...appState.products[generalProductIndex],
            name,
            description,
            price,
            category,
            location,
            stock
        };
    }
    
    saveToLocalStorage();
    
    addProductModal.style.display = 'none';
    addProductForm.reset();
    
    // Restaurar el comportamiento original del formulario
    addProductForm.removeEventListener('submit', arguments.callee);
    addProductForm.addEventListener('submit', handleAddProduct);
    
    const submitBtn = addProductForm.querySelector('button[type="submit"]');
    submitBtn.textContent = 'Registrar Producto';
    submitBtn.removeAttribute('data-edit-id');
    
    renderUserProducts();
    renderProducts();
    
    alert('Producto actualizado exitosamente');
}

function deleteProduct(productId) {
    if (confirm('¿Estás seguro de que quieres eliminar este producto?')) {
        appState.userProducts = appState.userProducts.filter(p => p.id !== productId);
        appState.products = appState.products.filter(p => p.id !== productId);
        
        saveToLocalStorage();
        
        renderUserProducts();
        renderProducts();
        
        alert('Producto eliminado exitosamente');
    }
}

// Configurar listeners de productos
function setupProductListeners() {
    addProductForm.addEventListener('submit', (e) => {
        e.preventDefault();
        handleAddProduct();
    });

    cancelAddProduct.addEventListener('click', () => {
        addProductModal.style.display = 'none';
        addProductForm.reset();
    });

    goToAddProduct.addEventListener('click', () => {
        inventoryModal.style.display = 'none';
        addProductModal.style.display = 'flex';
    });
}